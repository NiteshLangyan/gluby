$('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
  if (!$(this).next().hasClass('show')) {
    $(this).parents('.dropdown-menu').first().find('.show').removeClass("show");
  }
  var $subMenu = $(this).next(".dropdown-menu");
  $subMenu.toggleClass('show');


  $(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function(e) {
    $('.dropdown-submenu .show').removeClass("show");
  });


  return false;
});


$(document).ready(function() {
    $('.number-type').on('keypress', function (eve) {
        var curVal = $(this).val();
        console.log('event', eve.which);
        if((eve.which > 47 && eve.which < 58) || eve.which == 8 || eve.which == 46 ||  eve.which == 190 || eve.which == 0){

            if( curVal.indexOf('.') > -1 && eve.which == 46){
                return false;
            }

            if((curVal).indexOf('.') > -1 && !(eve.which == 8 || eve.which == 0)){
                var decimalStr = curVal.substr(curVal.indexOf('.') + 1);
                console.log('Here 2 ', decimalStr);
                if(decimalStr.length >= 2){
                    return false;
                }
            }
            console.log('Here ', curVal);
        }else{
            return false;
        }
    });
});




function validateFloatKeyPress(el) {
    var v = parseFloat(el.value);
    el.value = (isNaN(v)) ? '' : v.toFixed(2);
}

function validateFloat(eve){
    console.log('Evvent ',eve.which);
    // ele.value =  ele.value.replace(/[^\d.]/g, '')             // numbers and decimals only
    //     .replace(/(\..*)\./g, '$1')         // decimal can't exist more than once
    //     .replace(/(\.[\d]{2})./g, '$1');
    if((eve.which < 48 || eve.which > 57) || eve.which == 8 || eve.which == 46){
        console.log('Here');
    }
}

