@extends('layouts.app')

@section('content')
<div class="container">

<!--     @if (Session::has('success'))
      <div  class="alert alert-success">
        {{ Session::get('success') }}
      </div>
    @endif
 -->
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="list-group">
                  <a href="#" class="list-group-item list-group-item-action active">
                    Local Pot Calculations.
                  </a>
                  <h5 class="list-group-item list-group-item-action">
                    Calculated LP interest = {{ $lp_interest_amt }}                 
                  </h5>
                  <h5 class="list-group-item list-group-item-action">
                    Calculated GP Fee For LP = {{ $calc_lp_fee }}                 
                  </h5>
                  <h5 class="list-group-item list-group-item-action">
                    Calculated Amount Of Money To Spread = {{ $calc_spread_amt }}                 
                  </h5>
                  <h5 class="list-group-item list-group-item-action">
                    Calculated Amount Of Money To Trasnfer Each Member = {{ $amt_trnsf_each_member }}                 
                  </h5>

            </div>
        </div>
    </div>
</div>
@endsection