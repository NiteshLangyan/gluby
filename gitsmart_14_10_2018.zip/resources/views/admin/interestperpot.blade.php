@extends('admin.layouts.default ')

@section('admin.content')

<div class="btn-toolbar">
    <button class="btn btn-primary" disabled>New User</button>
    <button class="btn" disabled>Import</button>
    <button class="btn" disabled>Export</button>
</div>
<table class="table table-hover">

    <!--Table head-->
    <thead>
        <tr>
            <th>#</th>
            <th>Pot Name</th>
            <th>Type</th>
            <th>Interest Rate</th>
            <th>Edit</th>
        </tr>
    </thead>

    <!--Table body-->
    <tbody>
    @if(count($potInterests) > 0)
        @each('admin.admins._pot_rows', $potInterests, 'potInterests');
    @else
        no pots
    @endif

    </tbody>
<!--
<div class="pagination">
    <ul>
        <li><a href="#">Prev</a></li>
        <li><a href="#">1</a></li>
        <li><a href="#">2</a></li>
        <li><a href="#">3</a></li>
        <li><a href="#">4</a></li>
        <li><a href="#">Next</a></li>
    </ul>
</div>
-->
{{ $potInterests->links() }}
@endsection
