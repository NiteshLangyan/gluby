<tr>
    <th scope="row">{{$test->id}}</th>
    <td>{{ $test->pot->name}}</td>
    <td>{{ substr_replace($test->pot->amount,'.',-10,0) }}</td>
    <td>{{ $test->pot->owner->name }}</td> 
    <td>{{ count($test->pot->potTransactions()->toArray()) }}</td>
    <td>{{ $test->interest }}</td>
    <td>{{ $test->interest_rate}}</td>
    <td>{{ $test->updated_at }}</td>
    <td>
    <form method="POST" action="{{ route('admin.admins.simulate.store', [$test] ) }}">
            @csrf
            <button type="submit" class="btn btn-primary">Simulate</button>
        </form>
    </td>
</tr>