<tr>
    <th scope="row">{{$user->id}}</th>
    <td>{{$user->name}}</td>
    <td>{{$user->email}}</td>
    <td>{{ $user->role }}</td>
    <td>{{ $user->adminStatus() }}</td>
    <td>
    <form method="POST" action="{{ route('admin.admins.store', [$user] ) }}">
            @csrf
            <button type="submit" class="btn btn-primary">Switch</button>
        </form>
    </td>
</tr>