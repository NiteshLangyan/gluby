<tr>
    <th scope="row">{{$potInterests->id}}</th>
    <td>{{$potInterests->name}}</td>
    <td>{{$potInterests->type}}</td>
    <td>{{ $potInterests->interest_rate }}</td>
    <td>
        <a href="#" data-toggle="collapse" data-target="#{{$potInterests->id}}">Edit</a>
    </td>
<!--     <td>
    <form method="POST" action="{{ route('admin.interestperpot') }}">
            @csrf
            <button type="submit" class="btn btn-primary">Edit</button>
        </form>
    </td> -->
</tr>
<tr>
    <td id="{{$potInterests->id}}" class="panel-collapse collapse">
        <form method="POST" action="{{ route('admin.setnewinterest1',['potid' => $potInterests->id]) }}">
                @csrf
                <div class="form-group">
                    <input type="number" name="newintreset" id="password" tabindex="2" class="form-control" min="0.01" max="100" step="0.01" placeholder="Enter New Interest Rate">
                </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                <div class="form-group">
                </div>
        </form>
    </td>
</tr>