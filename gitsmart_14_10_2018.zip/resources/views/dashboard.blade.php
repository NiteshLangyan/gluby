@extends('layouts.app')

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                    <br>
@if(auth()->user()->isActive())
    your are a member
@else
                        Please subscrib to become glubi member
@endif
                </div>
            </div>
        </div>
    </div>
@endsection
