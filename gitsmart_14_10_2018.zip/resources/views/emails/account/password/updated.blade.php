@component('mail::message')
# Password Updated

We're just letting you know that your password was updated.

Thanks,<br>
{{ config('app.name') }}
@endcomponent
