<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/lib/jquery-3.2.1.min.js') }}"></script>
    <script src="{{ asset('js/lib/popper-1.11.0.min.js')}}"></script>
    <script src="{{ asset('js/lib/jquery.caret.js') }}"></script>
    <script src="{{ asset('js/app.js') }}" defer></script>
    <script src="{{ asset('js/navbar.js') }}"></script>
    <script src="{{ asset('js/scripts.js') }}"></script>

    <!-- Fonts  -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?calibri=:300,400,600" rel="stylesheet" type="text/css">


    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{ asset('css/style.css') }}" rel="stylesheet">
    <link href="{{ asset('css/bootstrap-4-navbar.css') }}" rel="stylesheet">

</head>
<body class="bg-white">
    <div id="app">
        @include('layouts.partials._navigation')
        <div class="container">
            <main class="py-4">
                @include('layouts.partials.alerts._alerts')
                @yield('content')
            </main>
        </div>
    </div>
    @yield('scripts')
</body>
</html>
