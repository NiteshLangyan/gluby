@if(session()->has('success'))
    @component('layouts.partials.alerts._alerts_component', ['type' => 'success'])
        {{ session('success') }}<strong> Well done</strong>.
    @endcomponent()
@endif

@if(session()->has('error'))
    @component('layouts.partials.alerts._alerts_component', ['type' => 'danger'])
        <strong>{{ session('error') }}</strong> You should check in on some of those fields below.
    @endcomponent()
@endif
