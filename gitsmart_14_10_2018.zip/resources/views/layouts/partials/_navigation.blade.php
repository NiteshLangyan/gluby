<header class="container-inner">
	<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #DCDCDC;">
		<a class="navbar-brand text-primary" href="{{ url('/') }}"> {{ config('app.name', 'Laravel') }}         </a>

		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>

		<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mr-auto"></ul>

			<!-- Right Side Of Navbar -->
			<ul class="navbar-nav mr-auto">
				<!-- <li class="nav-item active">
				<a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
				</li> -->
				<li class="nav-item">
					<a class="nav-link" href="#">Link</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">Link</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">Link</a>
				</li>
				<!-- <li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dropdown</a>
					<div class="dropdown-menu" aria-labelledby="navbarDropdown">
						<a class="dropdown-item" href="#">Action</a>
						<a class="dropdown-item" href="#">Another action</a>
						<div class="dropdown-divider"></div>
						<a class="dropdown-item" href="#">Something else here</a>
					</div>
				</li>
				<li class="nav-item">
					<a class="nav-link disabled" href="#">Disabled</a>
				</li> -->
			</ul>

			<!-- center Of Navbar -->
			<ul class="navbar-nav mr-auto">
				<li class="nav-item">
					<a class="btn btn-info my-2 my-sm-0" href="{{ route('donate.create') }}">{{ __('Donate') }}</a>
				</li>
			</ul>

			<!-- Left Side Of Navbar -->
			@guest
			<a class="btn btn-outline-primary my-2 my-sm-0" href="{{ route('register') }}">{{ __('Register') }}</a>
			<a class="btn btn-outline-primary my-2 my-sm-0" href="{{ route('login') }}">{{ __('Login') }}</a>
			@else
			@if(Auth::user()->type == 'admin')
			
			<ul class="navbar-nav mr-auto">
					<li><a class="btn btn-info my-2 my-sm-0" href="{{ Route('calcmoneytransfer') }}">GP SIM</a></li>
			</ul>
			<ul class="navbar-nav mr-auto">
					<li><a class="btn btn-info my-2 my-sm-0" href="{{ Route('calcmoneytransferlp') }}">LP SIM</a></li>
			</ul>
			@endif
			<ul class="navbar-nav ml-auto">
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="{{ route('account.index') }}" id="memberDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">{{ Auth::user()->name }}</a>
					<ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
						<li><h6 class="dropdown-header">GLUBI-Pot Actions</h6></li>
						<li><a class="dropdown-item" href="{{ Route('dashboard') }}">Overview</a></li>
						<!-- <li><a class="dropdown-item" href="javascript:void(0);">Global Pot (GP)</a></li> -->
						<li class="dropdown-submenu">
							<a class="dropdown-item dropdown-toggle" href="javascript:void(0);">Global Pot (GP)</a>
							<ul class="dropdown-menu">
								<li><h6 class="dropdown-header">GP Actions</h6></li>
								<li><a class="dropdown-item" href="{{ Route('dashboard') }}">Overview</a></li>
								<li><a class="dropdown-item" href="javascript:void(0);">Manage GP</a></li>
								<li><hr></li>
								<li><a class="dropdown-item" href="javascript:void(0);">Donate</a></li>
								<li><a class="dropdown-item" href="javascript:void(0);">Invest</a></li>
								<li><hr></li>
							</ul>
						</li>
						<li class="dropdown-submenu">
							<a class="dropdown-item dropdown-toggle" href="javascript:void(0);">Local Pot (LP)</a>
							<ul class="dropdown-menu">
								<li><h6 class="dropdown-header">LP Actions</h6></li>
								<li><a class="dropdown-item" href="{{ Route('dashboard') }}">Overview</a></li>
								<li><a class="dropdown-item" href="javascript:void(0);">Manage LP</a></li>
								<li><hr></li>
								<li><a class="dropdown-item" href="javascript:void(0);">Donate</a></li>
								<li><a class="dropdown-item" href="javascript:void(0);">Invest</a></li>
								<li><hr></li>
								<li><a class="dropdown-item" href="javascript:void(0);">Add LP</a></li>
								<li><a class="dropdown-item" href="javascript:void(0);">Create LP</a></li>
								<li><a class="dropdown-item" href="javascript:void(0);">Erase LP</a></li>
								<li><hr></li>
							</ul>
						</li>
						<li><a class="dropdown-item" href="javascript:void(0);">Local Pot (LP)</a></li>
						<li><hr></li>
						<li><a class="dropdown-item" href="javascript:void(0);">Donate</a></li>
						@if(Auth::user()->type == 'admin')
							<li><a class="dropdown-item" href="{{ Route('test') }}">Set Interest %</a></li>
						@endif
						<li><a class="dropdown-item" href="javascript:void(0);">Invest</a></li>
						<li><hr></li>
						@if(auth()->user()->isAdmin())
						<li><a class="dropdown-item" href="{{ route('admin.index')}}">Admin</a></li>
						@endif
						<li><a class="dropdown-item" href="{{ url('account')}}">Account</a></li>
						<li><a class="dropdown-item" href="{{ Route('logout')}}">Logout</a></li>
					</ul>
				</li>
			</ul>
			@endguest
		</div>
	</nav>
	@guest
	@else
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#NavSecond" aria-controls="NavSecond" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>

			<div class="collapse navbar-collapse" id="NavSecond">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item active">
						<a class="nav-link" href="{{ Route('dashboard') }}">Overview <span class="sr-only">(current)</span></a>
					</li>
				</ul>
			</div>
		</nav>
	@endguest
</header>

{{--
	<nav class="navbar navbar-expand-md navbar-light navbar-laravel">
		<div class="container">
			<a class="navbar-brand" href="{{ url('/') }}">
				{{ config('app.name', 'Laravel') }}
			</a>

			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>

			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<!-- Left Side Of Navbar -->
				<ul class="navbar-nav mr-auto">
				</ul>

				<!-- Right Side Of Navbar -->
				<ul class="navbar-nav ml-auto">
					<!-- Authentication Links -->
					@guest
						<li><a class="nav-link bg-info text-white" href="{{ route('register') }}">{{ __('Register') }}</a></li>
						<li><a class="nav-link btn-outline-info text-dark" href="{{ route('login') }}">{{ __('Login') }}</a></li>
					@else
						<li class="nav-item dropdown">
							<a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
								{{ Auth::user()->name }} <span class="caret"></span>
							</a>

							<div class="dropdown-menu" aria-labelledby="navbarDropdown">
								<a class="dropdown-item" href="{{ route('account.index') }}">
									{{ __('account') }}</a>
								<a class="dropdown-item" href="{{ route('logout') }}"
								onclick="event.preventDefault();
								document.getElementById('logout-form').submit();">
								{{ __('Logout') }}</a>

								<form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
									@csrf
								</form>
							</div>
						</li>
					@endguest
				</ul>
			</div>
		</div>
	</nav>
--}}
