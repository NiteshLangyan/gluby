<tr>
    <th scope="row">{{ $transaction->id }}</th>
    <td>{{ $transaction->user_id}}</td>
    <td>{{ substr_replace($transaction->amount,'.',-10,0)}}</td>
    <td>{{ $transaction->source_type}}</td>
    <td>{{ $transaction->source_id}}</td>
    <td>{{ $transaction->destination_type}}</td>
    <td>{{ $transaction->destination_id}}</td>
    <td>{{ $transaction->created_at }}</td>
    <td>{{ $transaction->updated_at }}</td>
</tr>