
@extends('member.layouts.default')

@section('member.content')




<div class="btn-toolbar">
    <button class="btn" disabled>Import</button>
    <button class="btn" disabled>Export</button>
</div>
<table class="table table-hover">

    <!--Table head-->
    <thead>
        <tr>
        <th>#</th>
            <th>User ID</th>
            <th>Amount</th>
            <th>Source Type</th>
            <th>Source ID</th>
            <th>Destination type</th>
            <th>Destination ID</th>
            <th>Creation</th>
            <th>Update</th>
        </tr>
    </thead>

    <!--Table body-->
    <tbody>
    @if(count($transactions) > 0)
        @each('member.transactions._transactions_rows', $transactions, 'transaction');
    @else
        no transactions
    @endif
    </tbody>

</table>
@endsection
