
@extends('member.layouts.default')

@section('member.content')

<div class="card">
    <div class="card-header">{{ __('Show Pot') }}</div>

    <div class="card-body">

    <div class="form-group row">
        <label for="owner" class="col-md-4 col-form-label text-md-right">{{ __('Owner') }}</label>

        <div class="col-md-6">
            <input disabled id="owner" type="text" class="form-control{{ $errors->has('owner') ? ' is-invalid' : '' }}" name="owner" value="{{ old('owner', $pot->owner->name ) }}" required>
        </div>
    </div>
            
    <div class="form-group row">
        <label for="amount" class="col-md-4 col-form-label text-md-right">{{ __('Amount in Pot') }}</label>

        <div class="col-md-6">
            <input disabled id="amount" type="text" class="number-type form-control{{ $errors->has('amount') ? ' is-invalid' : '' }}" name="amount"  value="{{ old('amount', $pot->amount ) }}" required>
        </div>
    </div>
    
        <div class="form-group row">
            <label for="type" class="col-md-4 col-form-label text-md-right">{{ __('Type') }}</label>
            <div class="col-md-6">
            <input disabled id="type" type="text" class="form-control{{ $errors->has('type') ? ' is-invalid' : '' }}" value="{{ $pot->type }}">
            </div>
        </div>

        <div class="form-group row">
            <label for="name" class="col-sm-4 col-form-label text-md-right">{{ __('Name') }}</label>

            <div class="col-md-6">
                <input disabled id="name" type="text" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" value="{{ $pot->name }}" required autofocus>
            </div>
        </div>
       

        <div class="card-header">{{ __('Pot Donation') }}</div>

        <div class="card-body">
            <form action="{{ route('member.memberships.store', [$pot]) }}" method="POST">
                @csrf
                <div class="form-group row">
                    <label for="amount_wallet" class="col-md-4 col-form-label text-md-right">{{ __('Amount in Wallet') }}</label>
                    <div class="col-md-6">
                        <input id="amount_wallet" type="text" class=" number-type form-control{{ $errors->has('amount_wallet') ? ' is-invalid' : '' }}" name="amount_wallet"  value="{{ old('amount_wallet') }}" required>
                        @if ($errors->has('amount_wallet'))
                    <span class="invalid-feedback">
                        <strong>{{ $errors->first('amount_wallet') }}</strong>
                    </span>
                @endif
                    </div>
                </div>
                <div class="form-group row mb-0">
                        <div class="col-md-4 offset-md-4">
                            <button type="submit" class="btn btn-success btn-lg btn-block">{{ __('Donate') }}</button>
                        </div>
                </div>
                
            </form>
        </div>

        <div class="card-footer bg-transparent border-success">Donations to this pot</div>
        <table class="table">
        <thead class="thead-dark">
            <tr>
                <th>#</th>
                <th>User ID</th>
                <th>Amount</th>
                <th>Source Type</th>
                <th>Source ID</th>
                <th>Destination type</th>
                <th>Destination ID</th>
                <th>Creation</th>
                <th>Update</th>
            </tr>
        </thead>
        <tbody>
            @if(count($transactions) > 0)
                @each('member.membership._transactions', $transactions, 'transaction');
            @else
                no donation
            @endif
        </tbody>
        </table>

    </div>
</div>


@endsection
