
@extends('account.layouts.default ')

@section('account.content')

<div class="card">
    <div class="card-header">Set GP-fee</div>

    <div class="card-body">
        <form method="POST" action="{{ route('member.pots.set.gpfee') }}">
            @csrf
            <div class="form-group row">
                <label for="gpfee" class="col-md-4 col-form-label text-md-right">Enter GP-fee</label>

                <div class="col-md-6">
                <input id="gpfee" type="number" class="form-control{{ $errors->has('gpfee') ? ' is-invalid' : '' }}" name="gpfee" value="{{ old('gpfee', 1) }}" min="1.00" max="100"  step="any">

                    @if ($errors->has('gpfee'))
                        <span class="invalid-feedback">
                            <strong>{{ $errors->first('gpfee') }}</strong>
                        </span>
                    @endif
                </div>
            </div>
            @if($count)
            <div class="form-group row">
                <label for="email" class="col-sm-4 col-form-label text-md-right">Select Pot</label>

                <div class="col-md-6">
                    <!-- <input id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email', auth()->user()->email) }}" required autofocus> -->
                    <div class="form-group">
                      <select class="form-control" name="pot_id" id="pot_id">
                        @foreach($potname as $pot)
                          <option value="{{ $pot->id }}">{{ $pot->name }}</option>
                        @endforeach
                      </select>
                    </div>
                    @if ($errors->has('pot_id'))
                        <span class="invalid-feedback">
                            <strong>{{ $errors->first('pot_id') }}</strong>
                        </span>
                    @endif
                </div>
            </div>
            @endif
            <div class="form-group row mb-0">
                <div class="col-md-8 offset-md-4">
                    <button type="submit" class="btn btn-primary">
                        Submit
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection
