<tr>
    <th scope="row">{{ $pot->id }}</th>
    <td>{{ $pot->name }}</td>
    <td>{{ $pot->owner->name }}</td>
    <td>{{ substr_replace($pot->amount,'.',-10,0) }}</td>
    <td>{{ $pot->type }}</td>
    <td>{{ $pot->created_at }}</td>
    <td>{{ $pot->updated_at }}</td>    
    <td><a class="btn btn-primary" href="{{ route('member.pots.edit', [$pot] ) }}">Update</a></td>
</tr>