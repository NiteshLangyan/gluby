
@extends('member.layouts.default')

@section('member.content')

<div class="card">
    <div class="card-header">{{ __('Pot Modification') }}</div>

    <div class="card-body">
            
    <div class="form-group row">
        <label for="amount" class="col-md-4 col-form-label text-md-right">{{ __('Amount in Pot') }}</label>

        <div class="col-md-6">
            <input disabled id="amount" type="text" class="form-control{{ $errors->has('amount') ? ' is-invalid' : '' }}" name="amount" value="{{ old('amount', substr_replace($pot->amount,'.',-10,0) ) }}" required>
        </div>
    </div>
    <div class="form-group row">
        <label for="interest_rate" class="col-md-4 col-form-label text-md-right">{{ __('Ineterest Rate') }}</label>

        <div class="col-md-6">
            <input disabled id="interest_rate" type="text" class="form-control{{ $errors->has('interest_rate') ? ' is-invalid' : '' }}" value="{{ $pot->interest_rate }}">
        </div>
    </div>
    <div class="form-group row">
        <label for="interest_rate" class="col-md-4 col-form-label text-md-right">{{ __('Ineterest') }}</label>

        <div class="col-md-6">
            <input disabled id="interest" type="text" class="form-control{{ $errors->has('interest') ? ' is-invalid' : '' }}" value="{{ substr_replace($pot->interest,'.',-10,0) }}">
        </div>
    </div>


    <form method="POST" action="{{ route('member.pots.update', [$pot]) }}">
        @csrf
        @method('PATCH')

        <div class="form-group row">
            <label for="type" class="col-md-4 col-form-label text-md-right">{{ __('Type') }}</label>
            <div class="col-md-6">
                <div class="form-check">
                    <input class="form-check-input{{ $errors->has('type') ? ' is-invalid' : '' }}" type="radio" name="type" id="public" value="global" {{ old('type', $pot->type == 'public' ? 'checked' : '') }}>
                    <label class="form-check-label" for="public">
                        <!-- Global -->
                        Public
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input{{ $errors->has('type') ? ' is-invalid' : '' }}" type="radio" name="type" id="private" value="regular" {{ old('type', $pot->type == 'private' ? 'checked' : '') }}>
                    <label class="form-check-label" for="private">
                        Private
                    </label>
                </div>
                @if ($errors->has('amount'))
                    <span class="invalid-feedback">
                        <strong>{{ $errors->first('type') }}</strong>
                    </span>
                @endif
            </div>
        </div>

        <div class="form-group row">
            <label for="name" class="col-sm-4 col-form-label text-md-right">{{ __('Name') }}</label>

            <div class="col-md-6">
                <input id="name" type="text" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" value="{{ old('name', $pot->name) }}" required autofocus>

                @if ($errors->has('name'))
                    <span class="invalid-feedback">
                        <strong>{{ $errors->first('name') }}</strong>
                    </span>
                @endif
            </div>
        </div>
        <div class="form-group row mb-0">
            <div class="col-md-4 offset-md-4">
                    <button type="submit" class="btn btn-primary btn-lg btn-block">{{ __('Update Pot') }}</button>
                </div>
            </div>

    </form>
    </div>



        <div class="card-header">{{ __('Pot Donation') }}</div>

        <div class="card-body">
            <form action="{{ route('member.memberships.store', [$pot]) }}" method="POST">
                @csrf
                <div class="form-group row">
                    <label for="amount_wallet" class="col-md-4 col-form-label text-md-right">{{ __('Amount in Wallet') }}</label>
                    <div class="col-md-6">
                        <input id="amount_wallet" type="text" class="number-type form-control{{ $errors->has('amount_wallet') ? ' is-invalid' : '' }}" name="amount_wallet"  value="{{ old('amount_wallet') }}" required>
                        @if ($errors->has('amount_wallet'))
                    <span class="invalid-feedback">
                        <strong>{{ $errors->first('amount_wallet') }}</strong>
                    </span>
                @endif
                    </div>
                </div>
                <div class="form-group row mb-0">
                        <div class="col-md-4 offset-md-4">
                            <button type="submit" class="btn btn-success btn-lg btn-block">{{ __('Donate') }}</button>
                        </div>
                </div>
                
            </form>
        </div>


        <div class="card-footer bg-transparent border-success">Donations to this pot</div>

        <table class="table">
        <thead class="thead-dark">
            <tr>
            <th>#</th>
            <th>Amount</th>
            <th>Source ID</th>
            <th>Source</th>
            <th>Destination ID</th>
            <th>Destination</th>
            <th>Creation</th>
            </tr>
        </thead>
        <tbody>
            @if(count($transactions) > 0)
                @each('member.pots._transactions', $transactions, 'transaction');
            @else
                no donation
            @endif
        </tbody>
        </table>

    </div>
</div>


@endsection
