  
<tr>
<th scope="row">{{ $transaction->id }}</th>
    <td>{{ substr_replace($transaction->amount,'.',-10,0) }}</td>
    <td>{{ $transaction->source_id }}</td>
    <td>{{ $transaction->source }}</td>
    <td>{{ $transaction->destination_id }}</td>
    <td>{{ $transaction->destination }}</td>
    <td>{{ $transaction->created_at }}</td>
</tr>