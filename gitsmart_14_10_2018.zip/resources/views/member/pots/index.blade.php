
@extends('member.layouts.default')

@section('member.content')




<div class="btn-toolbar">
    <a class="btn btn-primary" href="{{ route('member.pots.create') }}">New Pot</a>
    <button class="btn" disabled>Import</button>
    <button class="btn" disabled>Export</button>
</div>
<table class="table table-hover">

    <!--Table head-->
    <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Pot owner</th>
            <th>Amount</th>
            <th>Type</th>
            <th>Creation</th>
            <th>Updated</th>
            <th>Update</th>
        </tr>
    </thead>

    <!--Table body-->
    <tbody>
    @if(count($pots) > 0)
        @each('member.pots._pots_rows', $pots, 'pot');
    @else
        no pots
    @endif
    </tbody>


@endsection
