@extends('member.layouts.default')

@section('member.content')
    you will see recent updates pots donations earnings and interests here
    <h1> your wallet : {{  bcdiv(  substr_replace(auth()->user()->wallet()->amount , '.', -10,0) , 1, 10) }} </h1>
@endsection
