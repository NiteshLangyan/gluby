<nav class="navbar navbar-light navbar-expand-sm px-0 flex-row flex-nowrap">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarWEX" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
     <div class="navbar-collapse collapse" id="navbarWEX">
        <div class="nav flex-sm-column flex-row nav-pills nav-stacked flex-column">
        <a class="nav-item nav-link {{ return_if(on_page('account'), 'active') }}" href={{ route('account.index') }}>Account</a> 
            <a class="nav-item nav-link {{ return_if(on_page('*/profile'), 'active') }}" href={{ route('account.profile.index') }}  >Profile</a>
            <a class="nav-item nav-link {{ return_if(on_page('*/password'), 'active') }}" href="{{ route('account.password.index') }}" >Change Password</a>
            <a class="nav-item nav-link {{ return_if(on_page('*member'), 'active') }}" href="{{ route('member.dashboard') }}">Member Dashboard</a>
            <a class="nav-item nav-link {{ return_if(on_page('donate'), 'active') }}" href="{{ route('donate.create') }}" >Donate</a>
            <a class="nav-item nav-link {{ return_if(on_page('*/donations'), 'active') }}" href="{{ route('member.donations.index') }}">Donations</a>
            <a class="nav-item nav-link {{ return_if(on_page('*/memberships'), 'active') }}{{ return_if(on_page('*/memberships/*'), 'active') }}" href="{{ route('member.memberships.index') }}">Pot Membership</a>
            <a class="nav-item nav-link {{ return_if(on_page('*/pots'), 'active') }} {{ return_if(on_page('*/pots/*'), 'active') }}" href="{{ route('member.pots.index') }}">Pots Ownership</a>
            <a class="nav-item nav-link {{ return_if(on_page('*/transactions'), 'active') }} {{ return_if(on_page('*/transactions/*'), 'active') }}" href="{{ route('member.transactions.index') }}">Transactions</a>
            <a class="nav-item nav-link {{ return_if(on_page('*/gp_fee'), 'active') }}"  href="{{ route('member.pots.show.gpfee') }}">Set GP-fee</a>
            <a class="nav-item nav-link {{ return_if(on_page('*/allpots'), 'active') }} {{ return_if(on_page('*/allpots/*'), 'active') }}" href="{{ route('allpots.index') }}">Public Pots</a>
        </div>
    </div>
</nav>
