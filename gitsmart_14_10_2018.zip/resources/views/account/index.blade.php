@extends('account.layouts.default')

@section('account.content')
@if(auth()->user()->isActive())
    your are a member
@else
                        Please subscrib to become glubi member
@endif
@endsection
