
@extends('account.layouts.default ')

@section('account.content')

<div class="card">
    <div class="card-header">{{ __('Donate') }}</div>

    <div class="card-body">
        <form method="POST" action="{{ route('donate.store') }}">
            @csrf
            <input type="hidden" name="payment_token" value="valid-token">


            <div class="form-group row">
                <label for="amount" class="col-md-4 col-form-label text-md-right">{{ __('Amount') }}</label>

                <div class="col-md-6">
                <input id="amount" type="text" class="form-control{{ $errors->has('amount') ? ' is-invalid' : '' }} number-type" name="amount" value="{{ old('amount', '1.00') }}" require  >

                    @if ($errors->has('amount'))
                        <span class="invalid-feedback">
                            <strong>{{ $errors->first('amount') }}</strong>
                        </span>
                    @endif
                </div>
            </div>
            <div class="form-group row">
                <label for="email" class="col-sm-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>

                <div class="col-md-6">
                    <input id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email', auth()->user()->email) }}"  required autofocus>

                    @if ($errors->has('email'))
                        <span class="invalid-feedback">
                            <strong>{{ $errors->first('email') }}</strong>
                        </span>
                    @endif
                </div>
            </div>
            <div class="form-group row mb-0">
                <div class="col-md-8 offset-md-4">
                    <button type="submit" class="btn btn-primary">
                        {{ __('Donate') }}
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection
