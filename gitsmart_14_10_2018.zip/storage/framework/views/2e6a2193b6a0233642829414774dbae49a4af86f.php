<?php $__env->startSection('member.content'); ?>
    you will see recent updates pots donations earnings and interests here
    <h1> your wallet : <?php echo e(auth()->user()->wallet()->amount); ?> </h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('member.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>