<?php $__env->startSection('member.content'); ?>




<div class="btn-toolbar">
    <button class="btn" disabled>Import</button>
    <button class="btn" disabled>Export</button>
</div>
<table class="table table-hover">

    <!--Table head-->
    <thead>
        <tr>
        <th>#</th>
            <th>User ID</th>
            <th>Amount</th>
            <th>Source Type</th>
            <th>Source ID</th>
            <th>Destination type</th>
            <th>Destination ID</th>
            <th>Creation</th>
            <th>Update</th>
        </tr>
    </thead>

    <!--Table body-->
    <tbody>
    <?php if(count($transactions) > 0): ?>
        <?php echo $__env->renderEach('member.transactions._transactions_rows', $transactions, 'transaction'); ?>;
    <?php else: ?>
        no transactions
    <?php endif; ?>
    </tbody>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('member.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>