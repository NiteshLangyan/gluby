<?php $__env->startSection('admin.content'); ?>

<div class="btn-toolbar">
    <button class="btn btn-primary" disabled>New User</button>
    <button class="btn" disabled>Import</button>
    <button class="btn" disabled>Export</button>
</div>
<table class="table table-hover">

    <!--Table head-->
    <thead>
        <tr>
            <th>#</th>
            <th>Pot Name</th>
            <th>Pot Amount</th>
            <th>Pot Owner</th>
            <th>Pot Transactions</th>
            <th>Interest</th>
            <th>Interest Rate</th>
            <th>Updated</th>
            <th>Simulate</th>
        </tr>
    </thead>

    <!--Table body-->
    <tbody>
    <?php if(count($tests) > 0): ?>
        <?php echo $__env->renderEach('admin.tests._pots_rows', $tests, 'test'); ?>;
    <?php else: ?>
        no users
    <?php endif; ?>

    </tbody>
<!--
<div class="pagination">
    <ul>
        <li><a href="#">Prev</a></li>
        <li><a href="#">1</a></li>
        <li><a href="#">2</a></li>
        <li><a href="#">3</a></li>
        <li><a href="#">4</a></li>
        <li><a href="#">Next</a></li>
    </ul>
</div>
-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.default ', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>