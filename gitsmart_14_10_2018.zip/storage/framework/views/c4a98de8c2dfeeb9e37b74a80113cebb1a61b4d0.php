<tr>
    <th scope="row"><?php echo e($test->id); ?></th>
    <td><?php echo e($test->pot->name); ?></td>
    <td><?php echo e(number_format($test->pot->amount, 2 , '.' , ',')); ?></td>
    <td><?php echo e($test->pot->owner->name); ?></td> 
    <td><?php echo e(count($test->pot->potTransactions()->toArray())); ?></td>
    <td><?php echo e(number_format($test->interest, 2 , '.' , ',')); ?></td>
    <td><?php echo e(number_format($test->interest_rate, 2 , '.' , ',')); ?></td>
    <td><?php echo e($test->updated_at); ?></td>
    <td>
    <form method="POST" action="<?php echo e(route('admin.admins.simulate.store', [$test] )); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary">Simulate</button>
        </form>
    </td>
</tr>