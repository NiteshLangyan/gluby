  
<tr>
<th scope="row"><?php echo e($transaction->id); ?></th>
    <td><?php echo e($transaction->amount); ?></td>
    <td><?php echo e($transaction->source_id); ?></td>
    <td><?php echo e($transaction->source); ?></td>
    <td><?php echo e($transaction->destination_id); ?></td>
    <td><?php echo e($transaction->destination); ?></td>
    <td><?php echo e($transaction->created_at); ?></td>
</tr>