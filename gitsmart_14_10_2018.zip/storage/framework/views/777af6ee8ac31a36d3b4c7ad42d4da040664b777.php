<?php $__env->startSection('member.content'); ?>

<div class="card">
    <div class="card-header"><?php echo e(__('Pot Modification')); ?></div>

    <div class="card-body">
            
    <div class="form-group row">
        <label for="amount" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Amount in Pot')); ?></label>

        <div class="col-md-6">
            <input disabled id="amount" type="number" class="form-control<?php echo e($errors->has('amount') ? ' is-invalid' : ''); ?>" name="amount" step="any" value="<?php echo e(old('amount', $pot->amount )); ?>" required>
        </div>
    </div>
    <div class="form-group row">
        <label for="interest_rate" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Ineterest Rate')); ?></label>

        <div class="col-md-6">
            <input disabled id="interest_rate" type="number" class="form-control<?php echo e($errors->has('interest_rate') ? ' is-invalid' : ''); ?>" value="<?php echo e($pot->interest_rate); ?>">
        </div>
    </div>
    <div class="form-group row">
        <label for="interest_rate" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Ineterest')); ?></label>

        <div class="col-md-6">
            <input disabled id="interest" type="number" class="form-control<?php echo e($errors->has('interest') ? ' is-invalid' : ''); ?>" value="<?php echo e($pot->interest); ?>">
        </div>
    </div>


    <form method="POST" action="<?php echo e(route('member.pots.update', [$pot])); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>

        <div class="form-group row">
            <label for="type" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Type')); ?></label>
            <div class="col-md-6">
                <div class="form-check">
                    <input class="form-check-input<?php echo e($errors->has('type') ? ' is-invalid' : ''); ?>" type="radio" name="type" id="public" value="global" <?php echo e(old('type', $pot->type == 'public' ? 'checked' : '')); ?>>
                    <label class="form-check-label" for="public">
                        <!-- Global -->
                        Public
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input<?php echo e($errors->has('type') ? ' is-invalid' : ''); ?>" type="radio" name="type" id="private" value="regular" <?php echo e(old('type', $pot->type == 'private' ? 'checked' : '')); ?>>
                    <label class="form-check-label" for="private">
                        Private
                    </label>
                </div>
                <?php if($errors->has('amount')): ?>
                    <span class="invalid-feedback">
                        <strong><?php echo e($errors->first('type')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row">
            <label for="name" class="col-sm-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

            <div class="col-md-6">
                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name', $pot->name)); ?>" required autofocus>

                <?php if($errors->has('name')): ?>
                    <span class="invalid-feedback">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group row mb-0">
            <div class="col-md-4 offset-md-4">
                    <button type="submit" class="btn btn-primary btn-lg btn-block"><?php echo e(__('Update Pot')); ?></button>
                </div>
            </div>
        </div>
    </form>




        <div class="card-header"><?php echo e(__('Pot Donation')); ?></div>

        <div class="card-body">
            <form action="<?php echo e(route('member.memberships.store', [$pot])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                    <label for="amount_wallet" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Amount in Wallet')); ?></label>
                    <div class="col-md-6">
                        <input id="amount_wallet" type="number" class="form-control<?php echo e($errors->has('amount_wallet') ? ' is-invalid' : ''); ?>" name="amount_wallet" step="any" min="0.00" value="<?php echo e(old('amount_wallet')); ?>" required>
                        <?php if($errors->has('amount_wallet')): ?>
                    <span class="invalid-feedback">
                        <strong><?php echo e($errors->first('amount_wallet')); ?></strong>
                    </span>
                <?php endif; ?>
                    </div>
                </div>
                <div class="form-group row mb-0">
                        <div class="col-md-4 offset-md-4">
                            <button type="submit" class="btn btn-success btn-lg btn-block"><?php echo e(__('Donate')); ?></button>
                        </div>
                </div>
                
            </form>
        </div>


        <div class="card-footer bg-transparent border-success">Donations to this pot</div>
        <table class="table">
        <thead class="thead-dark">
            <tr>
            <th>#</th>
            <th>Amount</th>
            <th>Source ID</th>
            <th>Source</th>
            <th>Destination ID</th>
            <th>Destination</th>
            <th>Creation</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($transactions) > 0): ?>
                <?php echo $__env->renderEach('member.pots._transactions', $transactions, 'transaction'); ?>;
            <?php else: ?>
                no donation
            <?php endif; ?>
        </tbody>
        </table>

    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('member.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>