<nav class="navbar navbar-light navbar-expand-sm px-0 flex-row flex-nowrap">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarWEX" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
     <div class="navbar-collapse collapse" id="navbarWEX">
        <div class="nav flex-sm-column flex-row nav-pills nav-stacked flex-column">
            <a class="nav-item nav-link <?php echo e(return_if(on_page('admin'), 'active')); ?>" href=<?php echo e(route('admin.index')); ?>>Admin</a> 
            <a class="nav-item nav-link <?php echo e(return_if(on_page('*/admins'), 'active')); ?>" href=<?php echo e(route('admin.admins.index')); ?>>Admins</a>
            <a class="nav-item nav-link <?php echo e(return_if(on_page('*/tests'), 'active')); ?>" href=<?php echo e(route('admin.tests.index')); ?>>Testing</a>
            <a class="nav-item nav-link <?php echo e(return_if(on_page('*/setnewinterest'), 'active')); ?>" href=<?php echo e(route('admin.setnewinterest')); ?>>Set Interest Min/Max</a>
            <a class="nav-item nav-link <?php echo e(return_if(on_page('*/interestperpot'), 'active')); ?>" href=<?php echo e(route('admin.interestperpot')); ?>>Set Interest Per Pot</a>
        </div>
    </div>
</nav>
