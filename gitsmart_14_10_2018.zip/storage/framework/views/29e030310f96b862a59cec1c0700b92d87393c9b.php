<tr>
    <th scope="row"><?php echo e($user->id); ?></th>
    <td><?php echo e($user->name); ?></td>
    <td><?php echo e($user->email); ?></td>
    <td><?php echo e($user->role); ?></td>
    <td><?php echo e($user->adminStatus()); ?></td>
    <td>
    <form method="POST" action="<?php echo e(route('admin.admins.store', [$user] )); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary">Switch</button>
        </form>
    </td>
</tr>