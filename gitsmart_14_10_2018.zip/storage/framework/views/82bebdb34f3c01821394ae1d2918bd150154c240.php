<tr>
    <th scope="row"><?php echo e($test->id); ?></th>
    <td><?php echo e($test->pot->name); ?></td>
    <td><?php echo e(substr_replace($test->pot->amount,'.',-10,0)); ?></td>
    <td><?php echo e($test->pot->owner->name); ?></td> 
    <td><?php echo e(count($test->pot->potTransactions()->toArray())); ?></td>
    <td><?php echo e($test->interest); ?></td>
    <td><?php echo e($test->interest_rate); ?></td>
    <td><?php echo e($test->updated_at); ?></td>
    <td>
    <form method="POST" action="<?php echo e(route('admin.admins.simulate.store', [$test] )); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary">Simulate</button>
        </form>
    </td>
</tr>