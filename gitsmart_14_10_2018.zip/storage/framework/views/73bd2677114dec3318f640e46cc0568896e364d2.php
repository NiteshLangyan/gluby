<nav class="navbar navbar-light navbar-expand-sm px-0 flex-row flex-nowrap">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarWEX" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
     <div class="navbar-collapse collapse" id="navbarWEX">
        <div class="nav flex-sm-column flex-row nav-pills nav-stacked flex-column">
        <a class="nav-item nav-link <?php echo e(return_if(on_page('account'), 'active')); ?>" href=<?php echo e(route('account.index')); ?>>Account</a> 
            <a class="nav-item nav-link <?php echo e(return_if(on_page('*/profile'), 'active')); ?>" href=<?php echo e(route('account.profile.index')); ?>  >Profile</a>
            <a class="nav-item nav-link <?php echo e(return_if(on_page('*/password'), 'active')); ?>" href="<?php echo e(route('account.password.index')); ?>" >Change Password</a>
            <a class="nav-item nav-link <?php echo e(return_if(on_page('*member'), 'active')); ?>" href="<?php echo e(route('member.dashboard')); ?>">Member Dashboard</a>
            <a class="nav-item nav-link <?php echo e(return_if(on_page('donate'), 'active')); ?>" href="<?php echo e(route('donate.create')); ?>" >Donate</a>
            <a class="nav-item nav-link <?php echo e(return_if(on_page('*/donations'), 'active')); ?>" href="<?php echo e(route('member.donations.index')); ?>">Donations</a>
            <a class="nav-item nav-link <?php echo e(return_if(on_page('*/memberships'), 'active')); ?><?php echo e(return_if(on_page('*/memberships/*'), 'active')); ?>" href="<?php echo e(route('member.memberships.index')); ?>">Pot Membership</a>
            <a class="nav-item nav-link <?php echo e(return_if(on_page('*/pots'), 'active')); ?> <?php echo e(return_if(on_page('*/pots/*'), 'active')); ?>" href="<?php echo e(route('member.pots.index')); ?>">Pots Ownership</a>
            <a class="nav-item nav-link <?php echo e(return_if(on_page('*/transactions'), 'active')); ?> <?php echo e(return_if(on_page('*/transactions/*'), 'active')); ?>" href="<?php echo e(route('member.transactions.index')); ?>">Transactions</a>
            <a class="nav-item nav-link <?php echo e(return_if(on_page('*/gp_fee'), 'active')); ?>"  href="<?php echo e(route('member.pots.show.gpfee')); ?>">Set GP-fee</a>
            <a class="nav-item nav-link <?php echo e(return_if(on_page('*/allpots'), 'active')); ?> <?php echo e(return_if(on_page('*/allpots/*'), 'active')); ?>" href="<?php echo e(route('allpots.index')); ?>">Public Pots</a>
        </div>
    </div>
</nav>
