<?php $__env->startSection('member.content'); ?>




<div class="btn-toolbar">
    <a disabled class="btn btn-primary" href="<?php echo e(route('member.memberships.create')); ?>">New transaction</a>
    <button class="btn" disabled>Import</button>
    <button class="btn" disabled>Export</button>
</div>
<table class="table table-hover">

    <!--Table head-->
    <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Pot owner</th>
            <th>Amount</th>
            <th>Type</th>
            <th>Creation</th>
            <th>Updated</th>
        </tr>
    </thead>

    <!--Table body-->
    <tbody>
    <?php if(count($pots) > 0): ?>
        <?php echo $__env->renderEach('member.membership._pots_rows', $pots, 'pot'); ?>;
    <?php else: ?>
        no pots
    <?php endif; ?>
    </tbody>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('member.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>