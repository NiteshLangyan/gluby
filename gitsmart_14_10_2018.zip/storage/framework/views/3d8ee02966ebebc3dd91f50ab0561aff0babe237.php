<?php $__env->startSection('admin.content'); ?>
<div class="container">

    <?php if(Session::has('fail')): ?>
      <div  class="alert alert-danger">
        <?php echo e(Session::get('fail')); ?>

      </div>
    <?php endif; ?>

    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <?php if(Auth::user()->email == 'admin@glubi.org'): ?>
                <div class="card-header">Set Min/Max Interest Rate</div>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('admin.set_min_max_per')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <label for="minpercent" class="col-md-4 col-form-label text-md-right">Min Percent</label>

                                <div class="col-md-6">
                                    <input id="minpercent" type="number" class="form-control" name="minpercent" placeholder="Set Min. Percentage"  min="1" step="0.01" required >

                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="maxpercent" class="col-md-4 col-form-label text-md-right">Max Percent</label>

                                <div class="col-md-6">
                                    <input id="maxpercent" type="number" class="form-control" name="maxpercent" placeholder="Set Max. Percentage"  max="100" step="0.01" required >

                                </div>
                            </div>


                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        Submit
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                
                <?php else: ?>
                <div class="card-header">Enter POT Amount</div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <?php echo csrf_field(); ?>


                            <div class="form-group row">
                                <label for="amount" class="col-md-4 col-form-label text-md-right">Amount</label>

                                <div class="col-md-6">
                                    <input id="amount" type="text" class="form-control" name="lp_pot_amount" placeholder="Atleast 1$" required >

                                </div>
                            </div>


                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        Submit
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                <?php endif; ?>
     </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default ', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>