<tr>
    <th scope="row"><?php echo e($pot->id); ?></th>
    <td><?php echo e($pot->name); ?></td>
    <td><?php echo e($pot->owner->name); ?></td>
    <td><?php echo e($pot->amount); ?></td>
    <td><?php echo e($pot->type); ?></td>
    <td><?php echo e($pot->created_at); ?></td>
    <td><?php echo e($pot->updated_at); ?></td>    
    <td><a class="btn btn-primary" href="<?php echo e(route('member.pots.edit', [$pot] )); ?>">Update</a></td>
</tr>