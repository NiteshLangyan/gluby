<?php $__env->startSection('member.content'); ?>
    you will see recent updates pots donations earnings and interests here
    <h1> your wallet : <?php echo e(bcdiv(  substr_replace(auth()->user()->wallet()->amount , '.', -10,0) , 1, 10)); ?> </h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('member.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>