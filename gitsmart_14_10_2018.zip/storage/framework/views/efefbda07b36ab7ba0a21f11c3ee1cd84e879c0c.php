<a href="#">
<tr>
    <th scope="row"><?php echo e($pot->id); ?></th>
    <td><?php echo e($pot->name); ?></td>
    <td><?php echo e($pot->owner->name); ?></td>
    <td><?php echo e(substr_replace($pot->amount,'.',-10,0)); ?></td>
    <td><?php echo e($pot->type); ?></td>
    <td><?php echo e($pot->created_at); ?></td>
    <td><?php echo e($pot->updated_at); ?></td>
    <td><a class="btn btn-primary" href="<?php echo e(route('member.memberships.show', [$pot] )); ?>">Show</a></td>
</tr>
</a>
