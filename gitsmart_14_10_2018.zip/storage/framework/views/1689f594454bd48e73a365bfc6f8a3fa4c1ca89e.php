<?php $__env->startSection('member.content'); ?>

<div class="card">
    <div class="card-header"><?php echo e(__('Pot Creation')); ?></div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route('member.pots.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label for="type" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Type')); ?></label>
                <div class="col-md-6">
                    <div class="form-check">
                        <input class="form-check-input<?php echo e($errors->has('type') ? ' is-invalid' : ''); ?>" type="radio" name="type" id="global" value="global">
                        <label class="form-check-label" for="global">
                            Public
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input<?php echo e($errors->has('type') ? ' is-invalid' : ''); ?>" type="radio" name="type" id="regular" value="regular">
                        <label class="form-check-label" for="private">
                            Private
                        </label>
                    </div>
                    <?php if($errors->has('type')): ?>
                        <span class="invalid-feedback">
                            <strong><?php echo e($errors->first('type')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group row">
                <label for="name" class="col-sm-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                <div class="col-md-6">
                    <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                    <?php if($errors->has('name')): ?>
                        <span class="invalid-feedback">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group row mb-0">
                <div class="col-md-8 offset-md-4">
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(__('Create Pot')); ?>

                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('member.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>