<tr>
    <th scope="row"><?php echo e($transaction->id); ?></th>
    <td><?php echo e($transaction->user_id); ?></td>
    <td><?php echo e($transaction->amount); ?></td>
    <td><?php echo e($transaction->source_type); ?></td>
    <td><?php echo e($transaction->source_id); ?></td>
    <td><?php echo e($transaction->destination_type); ?></td>
    <td><?php echo e($transaction->destination_id); ?></td>
    <td><?php echo e($transaction->created_at); ?></td>
    <td><?php echo e($transaction->updated_at); ?></td>
</tr>