<?php $__env->startSection('account.content'); ?>

<div class="card">
    <div class="card-header">Set GP-fee</div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route('member.pots.set.gpfee')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label for="gpfee" class="col-md-4 col-form-label text-md-right">Enter GP-fee</label>

                <div class="col-md-6">
                <input id="gpfee" type="number" class="form-control<?php echo e($errors->has('gpfee') ? ' is-invalid' : ''); ?>" name="gpfee" value="<?php echo e(old('gpfee', 1)); ?>" min="1.00" max="100"  step="any">

                    <?php if($errors->has('gpfee')): ?>
                        <span class="invalid-feedback">
                            <strong><?php echo e($errors->first('gpfee')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <?php if($count): ?>
            <div class="form-group row">
                <label for="email" class="col-sm-4 col-form-label text-md-right">Select Pot</label>

                <div class="col-md-6">
                    <!-- <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email', auth()->user()->email)); ?>" required autofocus> -->
                    <div class="form-group">
                      <select class="form-control" name="pot_id" id="pot_id">
                        <?php $__currentLoopData = $potname; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($pot->id); ?>"><?php echo e($pot->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                    <?php if($errors->has('pot_id')): ?>
                        <span class="invalid-feedback">
                            <strong><?php echo e($errors->first('pot_id')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
            <div class="form-group row mb-0">
                <div class="col-md-8 offset-md-4">
                    <button type="submit" class="btn btn-primary">
                        Submit
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('account.layouts.default ', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>