<?php $__env->startSection('account.content'); ?>

<div class="card">
    <div class="card-header"><?php echo e(__('Donate')); ?></div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route('donate.store')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="payment_token" value="valid-token">;


            <div class="form-group row">
                <label for="amount" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Amount')); ?></label>

                <div class="col-md-6">
                <input id="amount" type="number" class="form-control<?php echo e($errors->has('amount') ? ' is-invalid' : ''); ?>" name="amount" value="<?php echo e(old('amount', 1)); ?>" require min="0.00"  step="any">

                    <?php if($errors->has('amount')): ?>
                        <span class="invalid-feedback">
                            <strong><?php echo e($errors->first('amount')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="email" class="col-sm-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                <div class="col-md-6">
                    <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email', auth()->user()->email)); ?>" required autofocus>

                    <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group row mb-0">
                <div class="col-md-8 offset-md-4">
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(__('Donate')); ?>

                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('account.layouts.default ', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>