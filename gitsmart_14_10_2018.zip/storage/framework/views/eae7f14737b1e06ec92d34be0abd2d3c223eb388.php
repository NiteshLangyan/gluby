<?php $__env->startSection('admin.content'); ?>
<div class="container">

<!--     <?php if(Session::has('success')): ?>
      <div  class="alert alert-success">
        <?php echo e(Session::get('success')); ?>

      </div>
    <?php endif; ?>
 -->
    <div class="row justify-content-center">
        <div class="col-md-12">
          <?php if($pot_type == 'global'): ?>
            <div class="list-group">
                  <a href="#" class="list-group-item list-group-item-action active">
                    Global Pot Calculations (Interest rate is set to random at back while user creation)
                  </a>
                  <h5 class="list-group-item list-group-item-action">
                    GP_fee For Global Pot = <?php echo e($gp_fee); ?>                 
                  </h5>
                  <h5 class="list-group-item list-group-item-action">
                    Total GP Amount = <?php echo e($gp_amount); ?>                 
                  </h5>
                  <h5 class="list-group-item list-group-item-action">
                    Calculated GP Interest = <?php echo e($gp_interest); ?>                 
                  </h5>
                  
                  <h5 class="list-group-item list-group-item-action">
                    Calculated Total Money To Spread = <?php echo e($tot_money_spread); ?>                 
                  </h5>

                  <h5 class="list-group-item list-group-item-action">
                    Total GP Members  = <?php echo e($total_gp_memb); ?>                 
                  </h5>
                  <h5 class="list-group-item list-group-item-action">
                    Amount To Each GP Members  = <?php echo e($amount_each_memb); ?>                 
                  </h5>
                  <h5 class="list-group-item list-group-item-action">
                    GP Amount After All Transactions = <?php echo e($add_gp_fee); ?>                 
                  </h5>

            </div>
            <?php else: ?>
            <div class="list-group">
                  <a href="#" class="list-group-item list-group-item-action active">
                    Local Pot Calculations (Interest rate is set to random at back while user creation)
                  </a>
                  <h5 class="list-group-item list-group-item-action">
                    GP_fee For Local Pot = <?php echo e($gp_fee); ?>                 
                  </h5>
                  <h5 class="list-group-item list-group-item-action">
                    Total LP Amount = <?php echo e($lp_amount); ?>                 
                  </h5>
                  <h5 class="list-group-item list-group-item-action">
                    Calculated LP Interest = <?php echo e($lp_interest); ?>                 
                  </h5>
                
                  <h5 class="list-group-item list-group-item-action">
                    Calculated Total Money To Spread = <?php echo e($tot_money_spread); ?>                 
                  </h5>

                  <h5 class="list-group-item list-group-item-action">
                    Total LP Members  = <?php echo e($total_lp_memb); ?>                 
                  </h5>
                  <h5 class="list-group-item list-group-item-action">
                    Amount To Each LP Members  = <?php echo e($amount_each_memb); ?>                 
                  </h5>
                  <h5 class="list-group-item list-group-item-action">
                    LP After Adding GP_fee Of LP To GP = <?php echo e($add_gp_fee); ?>                 
                  </h5>

            </div>
            <?php endif; ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default ', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>