<header class="container-inner">
	<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #DCDCDC;">
		<a class="navbar-brand text-primary" href="<?php echo e(url('/')); ?>"> <?php echo e(config('app.name', 'Laravel')); ?>         </a>

		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>

		<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mr-auto"></ul>

			<!-- Right Side Of Navbar -->
			<ul class="navbar-nav mr-auto">
				<!-- <li class="nav-item active">
				<a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
				</li> -->
				<li class="nav-item">
					<a class="nav-link" href="#">Link</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">Link</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">Link</a>
				</li>
				<!-- <li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dropdown</a>
					<div class="dropdown-menu" aria-labelledby="navbarDropdown">
						<a class="dropdown-item" href="#">Action</a>
						<a class="dropdown-item" href="#">Another action</a>
						<div class="dropdown-divider"></div>
						<a class="dropdown-item" href="#">Something else here</a>
					</div>
				</li>
				<li class="nav-item">
					<a class="nav-link disabled" href="#">Disabled</a>
				</li> -->
			</ul>

			<!-- center Of Navbar -->
			<ul class="navbar-nav mr-auto">
				<li class="nav-item">
					<a class="btn btn-info my-2 my-sm-0" href="<?php echo e(route('donate.create')); ?>"><?php echo e(__('Donate')); ?></a>
				</li>
			</ul>

			<!-- Left Side Of Navbar -->
			<?php if(auth()->guard()->guest()): ?>
			<a class="btn btn-outline-primary my-2 my-sm-0" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
			<a class="btn btn-outline-primary my-2 my-sm-0" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
			<?php else: ?>
			<?php if(Auth::user()->type == 'admin'): ?>
			
			<ul class="navbar-nav mr-auto">
					<li><a class="btn btn-info my-2 my-sm-0" href="<?php echo e(Route('calcmoneytransfer')); ?>">GP SIM</a></li>
			</ul>
			<ul class="navbar-nav mr-auto">
					<li><a class="btn btn-info my-2 my-sm-0" href="<?php echo e(Route('calcmoneytransferlp')); ?>">LP SIM</a></li>
			</ul>
			<?php endif; ?>
			<ul class="navbar-nav ml-auto">
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="<?php echo e(route('account.index')); ?>" id="memberDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo e(Auth::user()->name); ?></a>
					<ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
						<li><h6 class="dropdown-header">GLUBI-Pot Actions</h6></li>
						<li><a class="dropdown-item" href="<?php echo e(Route('dashboard')); ?>">Overview</a></li>
						<!-- <li><a class="dropdown-item" href="javascript:void(0);">Global Pot (GP)</a></li> -->
						<li class="dropdown-submenu">
							<a class="dropdown-item dropdown-toggle" href="javascript:void(0);">Global Pot (GP)</a>
							<ul class="dropdown-menu">
								<li><h6 class="dropdown-header">GP Actions</h6></li>
								<li><a class="dropdown-item" href="<?php echo e(Route('dashboard')); ?>">Overview</a></li>
								<li><a class="dropdown-item" href="javascript:void(0);">Manage GP</a></li>
								<li><hr></li>
								<li><a class="dropdown-item" href="javascript:void(0);">Donate</a></li>
								<li><a class="dropdown-item" href="javascript:void(0);">Invest</a></li>
								<li><hr></li>
							</ul>
						</li>
						<li class="dropdown-submenu">
							<a class="dropdown-item dropdown-toggle" href="javascript:void(0);">Local Pot (LP)</a>
							<ul class="dropdown-menu">
								<li><h6 class="dropdown-header">LP Actions</h6></li>
								<li><a class="dropdown-item" href="<?php echo e(Route('dashboard')); ?>">Overview</a></li>
								<li><a class="dropdown-item" href="javascript:void(0);">Manage LP</a></li>
								<li><hr></li>
								<li><a class="dropdown-item" href="javascript:void(0);">Donate</a></li>
								<li><a class="dropdown-item" href="javascript:void(0);">Invest</a></li>
								<li><hr></li>
								<li><a class="dropdown-item" href="javascript:void(0);">Add LP</a></li>
								<li><a class="dropdown-item" href="javascript:void(0);">Create LP</a></li>
								<li><a class="dropdown-item" href="javascript:void(0);">Erase LP</a></li>
								<li><hr></li>
							</ul>
						</li>
						<li><a class="dropdown-item" href="javascript:void(0);">Local Pot (LP)</a></li>
						<li><hr></li>
						<li><a class="dropdown-item" href="javascript:void(0);">Donate</a></li>
						<?php if(Auth::user()->type == 'admin'): ?>
							<li><a class="dropdown-item" href="<?php echo e(Route('test')); ?>">Set Interest %</a></li>
						<?php endif; ?>
						<li><a class="dropdown-item" href="javascript:void(0);">Invest</a></li>
						<li><hr></li>
						<?php if(auth()->user()->isAdmin()): ?>
						<li><a class="dropdown-item" href="<?php echo e(route('admin.index')); ?>">Admin</a></li>
						<?php endif; ?>
						<li><a class="dropdown-item" href="<?php echo e(url('account')); ?>">Account</a></li>
						<li><a class="dropdown-item" href="<?php echo e(Route('logout')); ?>">Logout</a></li>
					</ul>
				</li>
			</ul>
			<?php endif; ?>
		</div>
	</nav>
	<?php if(auth()->guard()->guest()): ?>
	<?php else: ?>
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#NavSecond" aria-controls="NavSecond" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>

			<div class="collapse navbar-collapse" id="NavSecond">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item active">
						<a class="nav-link" href="<?php echo e(Route('dashboard')); ?>">Overview <span class="sr-only">(current)</span></a>
					</li>
				</ul>
			</div>
		</nav>
	<?php endif; ?>
</header>


