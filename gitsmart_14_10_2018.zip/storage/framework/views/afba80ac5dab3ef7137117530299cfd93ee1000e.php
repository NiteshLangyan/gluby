<?php if(session()->has('success')): ?>
    <?php $__env->startComponent('layouts.partials.alerts._alerts_component', ['type' => 'success']); ?>
        <?php echo e(session('success')); ?><strong> Well done</strong>.
    <?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <?php $__env->startComponent('layouts.partials.alerts._alerts_component', ['type' => 'danger']); ?>
        <strong><?php echo e(session('error')); ?></strong> You should check in on some of those fields below.
    <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
