Install:

composer install
composer update
php artisan key:generate

edit your .env (your DB settings)

php artisan migrate:fresh
php artisan db:seed

Should be done.

###########################################
readme for Laravel boileplate

I created a fresh Laravel 5.6
default authentication schema
jobs and queues
    php artisan queue:table
    php artisan queue:failed-table
    queue driver set to database (mysql)
mailtrap to test emails
**
we change homecontroller and default home page
and then we do dashboardcontroller for login users
tweaking views to extract container class to app layouts
include partials for different parts

**
account controller inside account folder
account folder and views to be seperate from main layouts

**
create profile controller
profile routes and form request
ability to change profile name and email

**
ability to change password
create password views controller request routes and rules to add new rule
create mail that has mail views and mail class and notify users once email has been updated

I changed reditrect to home in auth controllers
**
plans functionality
created plans views model controller routes
create seed that contains plans
subscription controller
with views
I pulled laravel cahsier
and billing with stripe



-----------------------------
you clone to your local envirment
set database .env
you set your mailtrap or other mail service
{explanation of how to set services}
set .env the queue driver to be database
you set up stripe key and stripe secret
{ you will have my keys set up}




