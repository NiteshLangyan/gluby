<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\User;
use App\Billing\FakePaymentGateway;
use App\Billing\PaymentGateway;

class DonateFirstTimeTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp()
    {
        parent::setUp();

        $this->paymentGateway = new FakePaymentGateway;
        $this->app->instance(PaymentGateway::class, $this->paymentGateway);
    }
    
    /** @test */
    public function user_login_he_can_donate_become_member()
    {
        $this->withoutExceptionHandling();

        //arrange
        //create user
        $user = factory('App\User')->create(['email' => 'test@test.com']);
        $this->signIn($user);
        //$pot = factory('App\Pot')->create();


        //make sure he is signin 
        /*$this->get('/dashboard')
            ->assertSee($user->name);
        $this->assertDatabaseHas('users', ['email' => $user->email]);
         */
        //act
        //he go donate first time
        $this->json('POST', "/donate", [
            'email' => 'test@test.com',
            'amount' => 5,
            'payment_token' => $this->paymentGateway->getValidTestToken(),
        ])->assertStatus(201);
        
        //assert the request is succed
        //$this->assertStatus(201);

        //make sure a member was charged the amount of money
        $this->assertEquals( 5, $this->paymentGateway->totalCharges());
        
        //make sure pot exists for this member
        $donation = $user->donations()->where('id', $user->id)->first();
        $this->assertNotNull($donation);
        $this->assertEquals(5, $donation->amount);
    }

    /* email required email,
     * amount required integer min:1,
    * payment_token required */

    /** @test */
    public function payment_token_is_required()
    {
        $response = $this->json('POST', "/donate", [
            'email' => 'test@test.com',
            'amount' => 10,
        ])->assertStatus(422);
             $response->assertJsonValidationErrors('payment_token');
    }
    
    
    /** @test */
    public function amount_should_be_an_integer()
    {
        $response = $this->json('POST', "/donate", [
            'email' => 'test@test.com',
            'amount' => 'test',
            'payment_token' => $this->paymentGateway->getValidTestToken(),
        ])->assertStatus(422);
             $response->assertJsonValidationErrors('amount');
    }
    
    /** @test */
    public function amount_should_be_1_at_least()
    {
        $response = $this->json('POST', "/donate", [
            'email' => 'test@test.com',
            'amount' => 0,
            'payment_token' => $this->paymentGateway->getValidTestToken(),
        ])->assertStatus(422);
             $response->assertJsonValidationErrors('amount');
    }
    
    /** @test */
    public function amount_is_required()
    {
        $response = $this->json('POST', "/donate", [
            'email' => 'test@test.com',
            'payment_token' => $this->paymentGateway->getValidTestToken(),
        ])->assertStatus(422);
             $response->assertJsonValidationErrors('amount');
    }
    
    /** @test */
    public function email_field_should_be_a_valid_email()
    {
        $response = $this->json('POST', "/donate", [
            'email' => 'not-a-valid-email',
            'amount' => 5,
            'payment_token' => $this->paymentGateway->getValidTestToken(),
        ])->assertStatus(422);
             $response->assertJsonValidationErrors('email');
    }
    
    /** @test */
    public function email_is_required_to_donate()
    {

        //$this->withoutExceptionHandling();
        $response = $this->json('POST', "/donate", [ 
            'amount' => 5,
            'payment_token' => $this->paymentGateway->getValidTestToken(),
        ])->assertStatus(422);
             $response->assertJsonValidationErrors('email');
    } 
    
    
    

}
