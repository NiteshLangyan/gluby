<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTestsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tests', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('pot_id');
            $table->unsignedDecimal('interest_rate', 4, 2)->default(0.19);
            $table->unsignedDecimal('interest', 60, 20)->nullable();
            //$table->;
            //$table->;
            $table->timestamps();
            
            $table->foreign('pot_id')->references('id')->on('pots')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tests');
    }
}
