<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePotsTable extends Migration
{
    
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pots', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('user_id');
            $table->string('name')->unique();
            $table->string('amount')->default(0);
            //$table->unsignedDecimal('interest_rate', 8, 2)->default(0.19);
            //$table->unsignedDecimal('interest', 60, 20)->nullable();
            //$table->enum('visibility', ['private', 'public'])->default('private');
            $table->enum('type', ['global', 'regular', 'wallet', 'public', 'private'])->default('global');
            $table->timestamps();
            
            //$table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pots');
    }
}
