<?php

use Illuminate\Database\Seeder;

class GlobalPotSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        factory('App\Pot')->states('global')->create();
    }
}
