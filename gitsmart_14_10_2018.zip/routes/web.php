<?php

Auth::routes();

Route::get('/', 'HomeController@index')->name('home');
Route::get('/logout', 'Auth\LoginController@logout');


// AUTH
Route::group(['middleware' => ['auth'] ], function () {
    Route::get('/dashboard', 'DashboardController@index')->name('dashboard');

    /*
     * Donation
     */
    Route::get('/donate', 'DonationsController@create')->name('donate.create');
    Route::post('/donate', 'DonationsController@store')->name('donate.store');
    
    //SetPercent For Admin
    Route::post('admin/setinterest', 'SetInterestController@set_min_max_per')->name('admin.set_min_max_per');
    Route::get('admin/setinterest', 'SetInterestController@setinterest')->name('admin.setinterest');
    Route::get('admin/setnewinterest', 'SetInterestController@setadmin')->name('admin.setnewinterest');
    Route::get('admin/interestperpot', 'SetInterestController@interestperpot')->name('admin.interestperpot');
    Route::post('admin/interestperpot', 'SetInterestController@setnewinterest')->name('admin.setnewinterest1');
    // Route::get('/setinterest', 'SetInterestController@setadmin')->name('admin.setadmin');

// ACCOUNT    
    Route::group(['prefix' => 'account', 'as' => 'account.'], function () {
        Route::get('/', 'Account\AccountController@index')->name('index');
        //Route::post('/', 'Account\AccountController@store');
    
        /*
        * Profile
        */
        Route::get('profile', 'Account\ProfileController@index')->name('profile.index');
        Route::post('profile', 'Account\ProfileController@store')->name('profile.store');

        /*
        * Password
        */
        Route::get('password', 'Account\PasswordController@index')->name('password.index');
        Route::post('password', 'Account\PasswordController@store')->name('password.store');

        Route::get('/donate', 'DonationsController@create')->name('donate.create');
        Route::post('/donate', 'DonationsController@store')->name('donate.store');
    });


    Route::resource('allpots', 'PotsAllController')->parameters(['allpots' => 'pot']);
});


//Member
Route::middleware(['member'])->name('member.')->prefix('member')->namespace('Member')->group( function(){
    Route::get('/dashboard', 'MemberDashboardController@index')->name('dashboard');
    
    /*
     * Potes Owning
     */
    Route::resource('pots', 'PotsController')->parameters(['pots' => 'pot']);
    Route::get('pots/simulate/{pot}', 'PotsController@simulate')->name('pots.simulate');

    Route::get('gp_fee', 'PotsController@ShowGpFee')->name('pots.show.gpfee');
    Route::post('gp_fee', 'PotsController@SetGpFee')->name('pots.set.gpfee');

    /*
     * Potes Owning
     */
        

        /*
        Route::get('/', 'Member\PotsController@index')->name('index');
        Route::get('/create', 'Member\PotsController@create')->name('create');
        Route::post('/', 'Member\PotsController@store')->name('store');
        Route::get('/edit/{pot}', 'Member\PotsController@edit')->name('edit');
        Route::patch('/update/{pot}', 'Member\PotsController@update')->name('update');
 */ 

    /*
     * Potes memberships
     */

    Route::get('memberships', 'PotsMemberController@index')->name('memberships.index');
    Route::post('memberships/{pot}/membership', 'PotsMemberController@store')->name('memberships.store');
    Route::get('memberships/create', 'PotsMemberController@create')->name('memberships.create');
    Route::get('memberships/{pot}', 'PotsMemberController@show')->name('memberships.show');



    /*
     * Settings
     */
    Route::patch('/settings/{setting}', 'SettingsController@update')->name('settings.update');
 /*   Route::group(['prefix' => 'settings', 'as' => 'settings.'], function(){
        Route::resource('/', 'SettingsController');
    });
  /
    /*
     * Transactions
     */
    Route::group(['prefix' => 'transactions', 'as' => 'transactions.'], function(){
        Route::resource('/', 'TransactionsController');
    });

     /*
     * Donations
     */
    Route::group(['prefix' => 'donations', 'as' => 'donations.'], function(){
        Route::get('/', 'DonationsController@index')->name('index');

    });
});


////////////////////// roles
Route::group(['prefix' => 'admin', 'middleware' => ['admin'] , 'as' => 'admin.'], function () {

    /*
     * Roles
     */
    Route::get('/', 'Admin\AdministratorController@index')->name('index');
    Route::get('/admins', 'Admin\AdminsController@index')->name('admins.index');
    Route::post('/admins/{user}/role', 'Admin\AdminsController@store')->name('admins.store');
    Route::post('/tests/{test}/simulate', 'Admin\TestController@store')->name('admins.simulate.store');
    Route::resource('/tests', 'Admin\TestController');
});

Route::get('database', function(){
    Auth::LoginUsingId(2);
    return \App\Test::get();
    $pot = factory('App\Pot')->create();
   auth()->user()->potMembership($pot); 
   auth()->user()->potMembership($pot); 
   auth()->user()->potMembership($pot); 
    
   return auth()->user()->memberships()->get();
    $setting = factory('App\Setting')->create();

    
    return auth()->user()->memberships()->get();
    auth()->user()->memberships()->attach( $pot, ['member' => true , 'setting_id' => $setting->id ]);
    //auth()->user()->potMembership($pot);
    return \App\UserPotSet::get();
    auth()->user()->memberships()->attach($pot, [ 'setting_id' => factory('App\Setting')->create()->id ] );
    //
    return auth()->user();
    // what we store in trasactions once user donate from external to glubi
    // how we name a MA pot  
    // what are default settings for each pot when we create them ?

    // create a pot
    // relate user to pot with settings
    
    // to relate them again we need to
    // when triggering relate methog we need to



    return $pot = \App\Pot::find(1);
    
    return $pot->potSettingUser(2, 2);
    $pot2 = \App\Pot::create([ 'name' => rand(1, 150)]);
    $setting2 = \App\Setting::create([ 'name' => rand(1, 200)]);
    //$setting2 = \App\Setting::create([ 'name' => rand(1, 200)]);
    $pot2 = \App\Pot::find(2);
    $user = \App\User::find(2);
    //$set2 = \App\Setting::find(2);

    $user->pots()->save($pot2, ['setting_id' => $setting2->id ]);
    //$pot2->settings()->where('user_id', 2)->where('setting_id', 1)->get();
    $setting = $pot2->potSettingUser(2, 2); 
    return $setting;
    //return DB::table('pot_setting_user')->get();
 /*   return DB::table('pot_setting_user')->insert([
        'user_id' => 2,
        'pot_id' => 1,
        'setting_id' =>  1,
    ]);
  */ 
    return \App\Pot::get();
    return \App\Potation::all();
    return \App\Potation::find(1)->potator;
    // potation->pot
    echo \App\Potation::find(1)->pot . '<br><br>';
    //potation->potator
    echo \App\Potation::find(1)->potator . '<br><br>';
    //potation (pot donation)
    //echo \App\Potation::find(1) . '<br><br>';
    //pot->owner
    echo \App\Pot::find(1)->owner . '<br><br>' ;
    //pot->members
    foreach(\App\Pot::find(1)->potations as $potation){
        echo $potation . '<br><br>';
    }
    //user->pots
    foreach(\App\User::find(1)->pots as $pot){
        echo $pot . '<br><br>';
    }
    //user->potations (pot donation)
    foreach(\App\User::find(2)->potations as $potation){
        echo $potation->pivot . '<br><br>';        
    }
   
    /*
    foreach(\App\Pot::find(1)->members as $member){
        return $member;
    }
     */

    /*
    $yeah->potations()->each(function($potation){
        dd($potation->pivot->amount);
    });
$yes = \App\User::find(1)->pots()->each(function($pot){
});
return $yeah;  */     
 /*()->each(function($pot){
        echo $pot->potation;
        });*/
   /*     ->each(function($pot){
        echo $pot->name . "<br>";    
    });
    */          
/*    auth()->user()->pots()->each(function($pot){
        $pot->owners()->each(function($owner){
            echo $owner->name;
        });
    });
 */ 
 // php artisan migrate:fresh --seed
    // login using email and password already modified
    // donate money to become member all money will go to the Global Pot
    // donate more money to be on your wallet
    // now create a pot that will have at least the amount of the wallet
    // default interests are 19% (just for testing)
    // now to test the interests by simulate button
});
/*

    do we need a potation model and table or you prefer we use donations seperately and put donations in wallet then take money from wallet
        what are parameters inside a pot ? (owner name amount? interests intereates_rate)
        pot amount is a limit or what ?
        does donation to a pot have a limit ?
        do we need to calculate all donations related to a pot in pot table('pot_amount?') or we calculate that everytime (we check all donations related to a pot an   )?

        if user donate to a pot how do you want to call him active ?
            user active and passive is not very convinient because of we will have active and not active for user email activation

    a_user_can_login
        
    /***************************** 3 Actions at DonationsController 
    user_first_donation_will_be_in_GlobalPot
        assert in database ('donations', 'potable', 'pots:id[1] => amount', 'user:role => active')
        assert user become a member in user instance
        assert amount in global pot page
        assert in donations page

    user_second_donation_and_so_on_will_be_in_wallet
        assert in database ('donations' , 'user:wallet')
        assert in donations page
        assert in wallet page

    /**********************  6 Actions at PotsController (pot creation)
    a_user_can_create_a_pot
        assert in pots database ('pots')
        assert in pot list page

    /**********************  6 Actions at PotsController (pot creation)
    a_user_can_create_donation_to_his_pot
        assert in database ('user:wallets' , 'pots')
    a_user_can_donate_other_pots

    when_user_donate_we_will_be_able_to_see_that_in_pot_page








 * */


