<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\{
    Donation,
    Pot,
    Potation,
    Setting,
    Traits\RolesTrait,
    Traits\MoneyOperationsTrait,
};

class User extends Authenticatable
{
    use Notifiable, RolesTrait, MoneyOperationsTrait;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    protected $with = ['pots', 'memberships'];

    protected $casts = [
        'is_admin' => 'boolean',  
    ];

    // user->friends
    // user->friendsOfMine
    // user->friendsOfMe
    //$user->donations
    public function donations()
    {
        return $this->hasMany(Donation::class);
    }

    public function potations()
    {
        return $this->morphToMany(Pot::class, 'potable')->withPivot('amount')->withTimestamps();
        //return $this->hasMany(Pot::class)->using(Potation::class);
    }
    
    // user->pots
    public function pots()
    {
        return $this->hasMany('App\Pot', 'user_id', 'id');
                    //->withPivot('setting_id')->withTimestamps();
    }
    // user pot memberships
   public function memberships()
   {
       return $this->belongsToMany('App\Pot', 'user_pot_set', 'user_id', 'pot_id')
                    ->withPivot('setting_id', 'manager', 'member')
                    ->withTimestamps();
   }

    // user pot where he is manager
    public function managerOf()
    {
        return $this->memberships()->wherePivot('manager', true)->get();
    }

    // user pots where is member
    public function memberOf()
    {
        return $this->memberships()->wherePivot('member', true)->get();
    }

   // user pots where he is member and manager 
   public function managerAndMemberOf()
   {
       return $this->memberOf()->merge($this->managerOf());
   }
   
   public function potMembership($pot ,$setting = [])
   { 
    $set = \App\UserPotSet::where('user_id', auth()->user()->id )->where('pot_id', $pot->id)->get()->first();
    if(!$set){
        $setting = factory('App\Setting')->create();
        auth()->user()->memberships()->attach( $pot, ['setting_id' => $setting->id ]);
        return;
    }
    return;
   }
   
    public function wallet()
    {
        return $this->pots()->where('name', $this->email)->get()->first();
    }
    
    

    

/*
    public function settings()
    {
        return $this->hasManyThrough(
            Setting::class,
            Pot::class,
            'id', //forigen key on intermediate model (Pot)
            'id',   // forigen key on final model (Setting)
            'id', // local key
            'id'   // local key on intermediate model (pot)
            //'user_id'
        );
        //return $this->hasManyThrough(Pot::class, Setting::class);
    } 
    // user->pots
    // potation is donation in a pot
    // pot->potation will have pivot table of all donations related to it
    public function potations()
    {
        return $this->morphToMany(Pot::class, 'potable')->withPivot('amount')->withTimestamps();
        //return $this->hasMany(Pot::class)->using(Potation::class);
    }



 */


    //Contact CLASS
        /***************** has one phone number */ //one to one hasOne
        // phoneNumber() { return $this->hasOne(PhoneNumber::class, user_idd)}
            //  [user_id optional, it refers to user_id in phone_number table]
            // access the relationship 
                // $contact->phone_number (table name or just _ ?)
                // $contact->phoneNumber (function name)
    //PhoneNumber CLASS
        /**************** has one contact */ //one to one belongsTo
        // contact(){ return $this->belongsTo(Contact::class) }
            // access the relationship
                // $phoneNumber->contact (function name)




    //HasManyThrough
        // relationship to a relationship
        // User has Many Contacts
        // Contact has Many PhoneNumbers
            // User HasManyThrough PhoneNumbers
            // function phoneNumbers(){return $this->hasManyThrough(PhoneNumber::Class, Contact::class, param1, param2)}
            //param1 = the relationship key on the intermediate model (if not user_id)
            //param2 = relationship key on distance model (if not user_id)
    // User HasManyThrough Transactions 
    // User has Many Pots (pivot table user_id pot_id)
    // Pot has Many Settings (pivot table pot_id setting_id)




}
