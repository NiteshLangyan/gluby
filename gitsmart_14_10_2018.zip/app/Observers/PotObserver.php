<?php

namespace App\Observers;

use App\Pot;

class PotObserver
{
    /**
     * Handle to the pot "created" event.
     *
     * @param  \App\Pot  $pot
     * @return void
     */
    public function created(Pot $pot)
    { 
        if($pot->type == 'wallet'){
            \App\Test::create([
                'pot_id' => $pot->id,
                'interest_rate' => 0.00,
            ]);
            return;
        }
        // create interest for pot
        \App\Test::create([
            'pot_id' => $pot->id,
            'interest_rate' => 2.33,
        ]);
        return;
    }

    /**
     * Handle the pot "updated" event.
     *
     * @param  \App\Pot  $pot
     * @return void
     */
    public function updated(Pot $pot)
    {
        //
    }

    /**
     * Handle the pot "deleted" event.
     *
     * @param  \App\Pot  $pot
     * @return void
     */
    public function deleted(Pot $pot)
    {
        //
    }
}
