<?php

namespace App\Observers;

use App\UserPotSet;

class UserPotSetObserver
{
    /**
     * Handle to the user pot set "created" event.
     *
     * @param  \App\UserPotSet  $userPotSet
     * @return void
     */
    public function created(UserPotSet $userPotSet)
    {
        //
    }

    /**
     * Handle the user pot set "updated" event.
     *
     * @param  \App\UserPotSet  $userPotSet
     * @return void
     */
    public function updated(UserPotSet $userPotSet)
    {
        //
    }

    /**
     * Handle the user pot set "deleted" event.
     *
     * @param  \App\UserPotSet  $userPotSet
     * @return void
     */
    public function deleted(UserPotSet $userPotSet)
    {
        //
    }
}
