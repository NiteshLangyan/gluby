<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Setpercent;
use App\gpamount;
use App\lpamount;
use DB;

class CalcGpLpController extends Controller
{
    public function calc_money_transfer(Request $request)
    {

    	$gp_fee = 1; 
		$total_gp = 0;
		$user_id = auth()->user()->id;

 		$amt_each = DB::table('lpamounts')->get();
 	  	
 	  	//Donate 1% to Global Pot 
 	  	foreach ($amt_each as $value) {
	  				$per_amt = $value->amount * ($gp_fee/100);

	  				$total_gp = $total_gp + $per_amt;

	  				$update_lp_amt = $value->amount - $per_amt;

	  				//update lpamounts as amount is deducted from this table for gp_fee
	  				DB::table('lpamounts')
	  				    ->where('user_id', $value->user_id)
	  				    ->update(['amount' => $update_lp_amt]);
	  		}

	  		$gpcount = gpamount::count();

	  			if ($gpcount > 0) {
	  				$set_gp_amt = DB::table('gpamounts')
	  				            ->where('user_id', $user_id)
	  				            ->update(['gp_amount' => $total_gp]);
	  			}else {
	             	
	            	 $gpamount = new gpamount;

	            	 $gpamount->user_id = $user_id;
	            	 $gpamount->gp_amount = $total_gp;
	            	 $gpamount->save();
	             }  

	             //Calculate Interest on GP
	             $gp_interest_rate = 2.33; //percent
	             $get_gp_amt = DB::table('gpamounts')->select('gp_amount')->first();
	             $gp_interest_amt = $get_gp_amt->gp_amount * ($gp_interest_rate/100);

	             //Calculate GP_fee
	             $calc_gp_fee = $gp_interest_amt * ($gp_fee/100);

	             //Calculate amount of money for spread
	             $calc_spread_amt = $gp_interest_amt - $calc_gp_fee;

	             //Calculate amount of money to transfer to each Global Pot member
	             $gp_users_no = DB::table('users')->where('pot_type','gp')->get()->count();
				 $amt_trnsf_each_member = $calc_spread_amt/$gp_users_no;

				 //Add GP_fee to GP
				 $add_gpfee_gp = $get_gp_amt->gp_amount + $calc_gp_fee;
				 DB::table('gpamounts')
				    ->where('user_id', $user_id)
				    ->update(['gp_amount' => $add_gpfee_gp]);

	             return view('gpcalculation', compact([
	             					'gp_interest_amt', 
	             					'calc_gp_fee',
	             					'calc_spread_amt',
	             					'amt_trnsf_each_member',
	             				]));
	  				// echo "Amount = ".$value->amount. " , Percent to apply = ".$min."paise add to Ammoumt = ".$per_amt."<br>";
 	  	
    }

    public function calc_money_transfer_lp(Request $request)
    {

    	$gp_fee = 1.25; 
		$total_lp = 0;
		$user_id = auth()->user()->id;

 		$amt_each = DB::table('lpamounts')->get();
 	  	
 	  	//Donate 1% to Global Pot 
 	  	foreach ($amt_each as $value) {
	  				// $per_amt = $value->amount * ($gp_fee/100);

	  				$total_lp = $total_lp + $value->amount;

	  				// $update_lp_amt = $value->amount - $per_amt;

	  				//update lpamounts as amount is deducted from this table for gp_fee
	  				// DB::table('lpamounts')
	  				//     ->where('user_id', $value->user_id)
	  				//     ->update(['amount' => $update_lp_amt]);
	  		}

	  		// $gpcount = gpamount::count();

	  		// 	if ($gpcount > 0) {
	  		// 		$set_gp_amt = DB::table('gpamounts')
	  		// 		            ->where('user_id', $user_id)
	  		// 		            ->update(['gp_amount' => $total_gp]);
	  		// 	}else {
	             	
	    //         	 $gpamount = new gpamount;

	    //         	 $gpamount->user_id = $user_id;
	    //         	 $gpamount->gp_amount = $total_gp;
	    //         	 $gpamount->save();
	    //          }  

	             //Calculate Interest on LP
	             $lp_interest_rate = 3.5; //percent
	             $lp_interest_amt = $total_lp * ($lp_interest_rate/100);

	             //Calculate GP_fee For LP
	             $calc_lp_fee = $lp_interest_amt * ($gp_fee/100);

	             //Calculate amount of money for spread
	             $calc_spread_amt = $lp_interest_amt - $calc_lp_fee;

	             //Calculate amount of money to transfer to each Local Pot member
	             $lp_users_no = lpamount::count();
				 $amt_trnsf_each_member = $calc_spread_amt/$lp_users_no;

				 //Add GP_fee Of LP to GP
	             $get_gp_amt = DB::table('gpamounts')->select('gp_amount')->first();
				 $add_lpfee_gp = $get_gp_amt->gp_amount + $calc_lp_fee;
				 DB::table('gpamounts')
				    ->where('user_id', $user_id)
				    ->update(['gp_amount' => $add_lpfee_gp]);

	             return view('lpcalculation', compact([
	             					'lp_interest_amt', 
	             					'calc_lp_fee',
	             					'calc_spread_amt',
	             					'amt_trnsf_each_member',
	             				]));
	  				// echo "Amount = ".$value->amount. " , Percent to apply = ".$min."paise add to Ammoumt = ".$per_amt."<br>";
 	  	
    }



}
