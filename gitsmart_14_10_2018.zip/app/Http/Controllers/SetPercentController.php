<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Setpercent;
use DB;

class SetPercentController extends Controller
{
	public function index()
	{
		# code...
	}
	public function set_min_max_per(Request $request)
	{
		 $min = $request->minpercent;
		 $max = $request->maxpercent;
		 
		 $user_id = auth()->user()->id;
		
		 $count = Setpercent::count();

	
		 if ($count > 0) {
		 $per = DB::table('setpercents')
		             ->where('user_id', $user_id)
		             ->update(['min' => $min,'max' => $max]);

		 }else{
		 	
			 $per = new Setpercent;

			 $per->min = $min;
			 $per->max = $max;
			 $per->user_id = $user_id;
			 $per->save();
		 }

		 if ($min == $max) {
		 		$amt_each = DB::table('lpamounts')->get();
		 	  	
		 	  	foreach ($amt_each as $value) {
	 	  				$per_amt = ($value->amount*$min)/100;

	 	  				$total = $value->amount + $per_amt;
	 	  				DB::table('lpamounts')
	 	  				            ->where('user_id', $value->user_id)
	 	  				            ->update(['amount' => $total]);
	 	  				// echo "Amount = ".$value->amount. " , Percent to apply = ".$min."paise add to Ammoumt = ".$per_amt."<br>";
		 	  	}
		 	  	// die();
		 	return redirect()->back()->with('success', 'Updated Amount Of Each Local Pot With Equal Percent.'); 
		 }

		 return redirect()->back()->with('success', 'Percent Set successfully'); 
		// dd($request->all());
	}
    
}
