<?php

namespace App\Http\Controllers\Member;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Pot;
use App\Test;
use App\GpFee;
use App\Setpercent;
use DB;
use App\Http\Requests\Pot\{
    PotStoreRequest,
    PotUpdateRequest
};

class PotsController extends Controller
{
    // pots you created
    public function index()
    {
        return view('member.pots.index')->with('pots' , 
            auth()->user()->pots()->get()
        );
    }
    public function show(Pot $pot)
    {
        $transactions = $pot->potTransactions();
        return view('member.membership.show', compact('pot', 'transactions'));
    }
    
    
    // 8
    // 10
    // table normalisation

    public function create()
    {
        return view('member.pots.create');
    }

    public function store(PotStoreRequest $request)
    {
        if (request('type') == 'global') $type = 'public'; 
            elseif (request('type') == 'regular') $type = 'private'; 
        $pot = Pot::create([ 'user_id' => auth()->user()->id  ,'type' => $type, 'name' => request('name') ]);
        auth()->user()->pots()->save($pot, ['setting_id' => factory('App\Setting')->create()->id]);

        // app('App\Http\Controllers\SetInterestController')->setinterest();

        // code for random number Generator starts here
            $setper = Setpercent::where('user_id', 1)->first();

            $lastid = DB::select('SELECT id FROM tests ORDER BY id DESC LIMIT 1');

            if (!empty($setper)) {
                if ($setper->min == $setper->max) 
                        DB::table('tests')->where('id', $lastid[0]->id)->update(['interest_rate' => $setper->max]); 
                else{
                        $randno = rand($setper->min, $setper->max);
                        DB::table('tests')->where('id', $lastid[0]->id)->update(['interest_rate' => $randno]); 
                }
            }
        // code for random number Generator ends here

        return redirect()->route('member.pots.index')->withSuccess('Pot created Successfully');
    }
    /*
        user potCreation potMemberShip
        user pots (name amount interest interest rate ) ( pot membership amount )
        //user will be able to create a pot
            it will have default amount 
            //user will be able to donate to a pot
            it will have a possibility to donate to any other pot

        //user will be able to create many pots without donating them


    public function store(PotStoreRequest $request)
    {
        $amount = request('amount');
        $user = auth()->user();

        $user->InWallet( (-$amount));
        $user->pots()->create(['amount' => $amount, 'name' => request('name') ]);
        
        return redirect()->route('member.pots.index')->withSuccess('Pot created Successfully');
    }
     */
    
    public function edit(Pot $pot)
    {
        $transactions = $pot->potTransactions();
        // dd($pot);
        //$setting = $pot->potSettingUser($pot->id, auth()->user()->id)->first();
        return view('member.pots.edit', compact('pot', 'transactions')); 
    }

    public function update(PotUpdateRequest $request, Pot $pot)
    {
     // dd($request);   
        if (request('type') == 'global') $type = 'public'; 
            elseif (request('type') == 'regular') $type = 'private'; 
        $pot->update(['type' => $type, 'name' => request('name') ]);

        return redirect()->route('member.pots.index')->withSuccess('Pot updated Successfully');
    }

    public function destroy()
    {
        dd('this functionality will be available soon');
    }
    
    
    
   public function simulate(Pot $pot)
   {
       $pot->calculateInterest();
       return back()->withSuccess('Interests calcuated successfully');
   }
   
    
   public function ShowGpFee()
   {
        $count = Pot::where('user_id',auth()->user()->id)->count();
        $potname = Pot::where('user_id',auth()->user()->id)->get();
        return view('member.pots.gpfee',compact('potname','count'));
   }

   public function SetGpFee(Request $request)
   {
        // dd($request->all());
        $potfee = $request->gpfee;
        $potid = $request->pot_id;

        GpFee::updateOrCreate(
                ['pot_id' => $potid], //If there is pot id with this id 
                ['gp_fee' => $potfee] //update GP_fee else create new
        );

       return back()->withSuccess('GP-fee Updated successfully');
   }
    
    


    
    
}
