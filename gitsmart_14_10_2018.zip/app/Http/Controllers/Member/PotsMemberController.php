<?php

namespace App\Http\Controllers\Member;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Pot;
use App\Http\Requests\Pot\PotMemberStoreRequest;
use App\Rules\WalletAmount;
use App\Rules\AmountMustBeDecimal;
use Illuminate\Support\Facades\DB;
use App\Transaction;
//use Illuminate\Database\DatabaseManager;
//use Illuminate\Database\Connection;


class PotsMemberController extends Controller
{

    // pots where you donated
    public function index()
    {
        $pots = auth()->user()->memberships()->get();
        return view('member.membership.index', compact('pots'));
    }

    public function create()
    {
        //
    }

    public function store(Request $request, Pot $pot)
    {
        $request->validate([ 'amount_wallet' => [new WalletAmount(), new AmountMustBeDecimal()] ]); 
        $amount = request('amount_wallet');
        $amount = str_replace('.','',number_format($amount,10));


        event(new \App\Events\UserPotDonation( auth()->user() , $amount , $pot ));
                
        return redirect()->route('member.pots.index')->withSuccess('Pot donation Successfully');
    }

    public function show(Pot $pot)
    {         
        $transactions = $pot->potTransactions();
        return view('member.membership.show', compact('pot', 'transactions'));

    }

    public function edit($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }
}
