<?php

namespace App\Http\Controllers\Member;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class DonationsController extends Controller
{
    public function index()
    {
        $transactions = \App\Transaction::where('user_id' , auth()->user()->id )->where('source_type' , 'external')->latest()->get();
        return view('member.donations.index', compact('transactions'));
    }
      
}
