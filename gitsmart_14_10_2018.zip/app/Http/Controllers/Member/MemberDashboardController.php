<?php

namespace App\Http\Controllers\Member;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Pot;

class MemberDashboardController extends Controller
{
    //
    
    public function index()
    {

        return view('member.index');
    }
    
    
}
