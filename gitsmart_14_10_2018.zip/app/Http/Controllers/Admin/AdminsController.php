<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;

class AdminsController extends Controller
{
    //
    
    public function index()
    {
        $users = User::get();
        return view('admin.admins.index', compact('users'));
    }

    public function store(User $user)
    {
        if($user->is_admin == true){
            $user->beNotAdmin();
            return back();    
        }
        $user->beAdmin();
        return back();    
    }
    
     
    
}
