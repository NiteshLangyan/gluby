<?php

namespace App\Http\Controllers\Admin;

use App\Test;
use App\GpFee;
use App\Pot;
use App\Transaction;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use Carbon\Carbon;

class TestController extends Controller
{
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tests = \App\Test::get();
        return view('admin.tests.index', compact('tests'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Test $test, Request $request)
    {   
        $dt = Carbon::now();

        $current_pot_id = $request->test->pot_id;
        // dd($request->test->pot_id);

        if ($test->pot->type == 'global') {
            $pot_type = 'global';
                
            $gpfee = GpFee::where('pot_id', $test->pot->id)->first();
            $gp_amount = $test->pot->amount;
            $gp_amount = substr_replace($gp_amount, '.', -10,0);
            $pot_id = Test::where('pot_id', '=', $test->pot->id)->first();
            $gp_interest = bcmul($gp_amount,bcdiv($pot_id->interest_rate,100,10),10);

            if($gpfee) {
                $gp_fee = bcmul($gp_interest, bcdiv($gpfee->gp_feev, 100, 10), 10);
            }else {
               // $gp_fee = 0; //0% of GP_fee
                $gp_fee = bcmul($gp_interest, bcdiv(0, 100, 10), 10);
            }

            $gp_fee_amount = $gp_fee;
            $tot_money_spread = bcsub($gp_interest, $gp_fee,10);
            $get_members = Transaction::distinct()
                                    ->where('destination_id', $current_pot_id )
                                    ->where('destination_type', 'internal' )
                                    ->where('source_type', 'internal' )
                                    ->where('source_id','!=', $current_pot_id)
                                    ->get(['source_id','destination_id']);
            $total_gp_memb = $get_members->count();

                if ($total_gp_memb == 0) {
                    $amount_each_memb = $tot_money_spread;
                }else {
                    // Used BC Math Functions here
                    $amount_each_memb = bcdiv($tot_money_spread, $total_gp_memb, 10);

                    $amount_each_memb_str = str_replace('.', '', $amount_each_memb);

                    $pot_user_id = Pot::where('id', $current_pot_id)->first();

                    foreach ($get_members as $pot) {

                        $pot_data = Pot::where('id', $pot->source_id)->first();
                        $current_pot_data_amount = substr_replace($pot_data->amount, '.',-10,0);
                        $update_pot_amount = bcadd( $current_pot_data_amount, $amount_each_memb, 10);
                        $update_pot_amount_str = str_replace('.', '', $update_pot_amount);
                        $update_amount = Pot::find($pot->source_id)
                            ->update(['amount' => $update_pot_amount_str]);


                        $new_trans = new Transaction;

                        $new_trans->user_id = $pot_user_id->user_id;
                        $new_trans->source_type = 'internal';
                        $new_trans->source_id = $pot->destination_id;
                        $new_trans->destination_type = 'internal';
                        $new_trans->destination_id = $pot->source_id;
                        $new_trans->amount = $amount_each_memb_str;
                        $new_trans->save();

                    }

                }

                $add_gp_fee = bcadd($gp_amount, $gp_fee,10);

                return view('potscalculation', compact([
                                    'pot_type', 
                                    'gp_fee', 
                                    'gp_amount', 
                                    'gp_interest',
                                    'gp_fee_amount',
                                    'tot_money_spread',
                                    // 'update_gp',
                                    'total_gp_memb',
                                    'amount_each_memb',
                                    'add_gp_fee'
                                ]));

        }else{

            $gpfee = GpFee::where('pot_id', $current_pot_id)->first();

            $lp_amount = $test->pot->amount;
            $lp_amount = substr_replace($lp_amount, '.', -10,0);

            $pot_id = Test::where('pot_id', '=', $current_pot_id)->first();

            $interest_rate = $pot_id->interest_rate;

            $lp_interest = bcmul($lp_amount,bcdiv($interest_rate,100,10),10);


            if($gpfee)
                $gp_fee = $gpfee->gp_fee;
            else
                $gp_fee = bcmul($lp_interest,bcdiv( 1.25 ,100,10),10);//1.25% of GP_fee
            
            $pot_type = 'local';
           // dd( $gp_fee);

            $gp_div = bcmul($lp_interest, $gp_fee);
                // echo 'Calculate GP_fee without divide by 100 = '.$gp_div.'<br>';
            $lp_fee_amount = bcdiv($gp_div,100);



            // Calculate Total amount of money to spread in all Local Pot members
            $tot_money_spread = bcsub($lp_interest, $gp_fee,10);
                // echo 'Total Amount to spread = '.$tot_money_spread.'<br>';

            $get_members = Transaction::distinct()
                                ->where('destination_id', $current_pot_id )
                                ->where('destination_type', 'internal' )
                                ->where('source_type', 'internal' )
                                ->where('source_id','!=', $current_pot_id)
                                ->get(['source_id','destination_id']);


            $total_lp_memb = $get_members->count();
            // dd($total_lp_memb);
            $rest_amount_to_gp = 0; //Global Variable

            if ($total_lp_memb == 0){
                    $amount_each_memb = $tot_money_spread;
            }else{                         // Bc math Functions are used there
                    $rest_amount_to_gp = bcmod($tot_money_spread, $total_lp_memb,10);

                    $amount_each_memb = bcdiv($tot_money_spread, $total_lp_memb,10);
                    $amount_each_memb_str = str_replace('.', '', $amount_each_memb);
                    
                    $pot_user_id = Pot::where('id',$current_pot_id)->first();
                    // dd($pot_user_id->user_id);
                    foreach ($get_members as $pot) {

                        $pot_data = Pot::where('id',$pot->source_id)->first();
                        $current_pot_data_amount = substr_replace($pot_data->amount, '.', -10,0);
                        $update_pot_amount = bcadd( $current_pot_data_amount, $amount_each_memb,10);
                        $update_pot_amount_str = str_replace('.','',$update_pot_amount);


                        $update_amount = Pot::find($pot->source_id)
                                            ->update(['amount' => $update_pot_amount_str]);
                        

                        $new_trans = new Transaction;

                        $new_trans->user_id = $pot_user_id->user_id;
                        $new_trans->source_type = 'internal';
                        $new_trans->source_id = $pot->destination_id;
                        $new_trans->destination_type = 'internal';
                        $new_trans->destination_id = $pot->source_id;
                        $new_trans->amount = $amount_each_memb_str;
                        $new_trans->save();
                    }
            }
            // Add GP_fee to Local Pot
            $add_gp_fee = bcadd($gpfee, $gp_fee,10);

            $pot_data = Pot::find($current_pot_id)->first();

            $pot_data = Pot::where('type','global')->first();
            $current_pot_data_amount = substr_replace($pot_data->amount, '.', -10,0);
            $amount_to_global = bcadd($current_pot_data_amount, $lp_fee_amount,10);
            $amount_to_global_str = str_replace('.', '', $amount_to_global);

            $new_trans = new Transaction;

            $new_trans->user_id = $pot_data->user_id;
            $new_trans->source_type = 'internal';
            $new_trans->source_id = $current_pot_id;
            $new_trans->destination_type = 'internal';
            $new_trans->destination_id = 1;
            $new_trans->amount = $lp_fee_amount;
            $new_trans->save();
            
            //Update Global Pot For rest of the amount after do bcmod() function above 
            if ($rest_amount_to_gp > 0) {
                $current_pot_data_amount = substr_replace($pot_data->amount, '.', -10,0);
                $amount_to_global_1 = bcadd($current_pot_data_amount, $rest_amount_to_gp,10);
                $amount_to_global_1_str = str_replace('.', '', $amount_to_global_1);
                    DB::table('pots')
                                ->where('type', 'global')
                                ->update(['amount' =>  $amount_to_global_1_str]);
            }

            DB::table('pots')
                        ->where('type', 'global')
                        ->update(['amount' => $amount_to_global_str]);

            return view('potscalculation', compact([
                                'pot_type', 
                                'gp_fee', 
                                'lp_amount', 
                                'lp_interest',
                                'lp_fee_amount',
                                'tot_money_spread',
                                'total_lp_memb',
                                'amount_each_memb',
                                'add_gp_fee'
                            ]));         
            
        }

        // dd($yes);
/*        if(!$yes <= 0 ){
            $test->interest = $test->pot->amount * $test->interest_rate;
            $test->save();
        }
*/
        // if($yes > 0 ){
        //     $test->interest = $test->pot->amount * $test->interest_rate;
        //     $test->save();
        // }

        return back()->withSuccess('Cant be calculated');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Test  $test
     * @return \Illuminate\Http\Response
     */
    public function show(Test $test)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Test  $test
     * @return \Illuminate\Http\Response
     */
    public function edit(Test $test)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Test  $test
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Test $test)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Test  $test
     * @return \Illuminate\Http\Response
     */
    public function destroy(Test $test)
    {
        //
    }
}
