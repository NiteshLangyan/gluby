<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Setminmax;
use App\Setpercent;
use App\User;
use App\Test;
use DB;


class SetInterestController extends Controller
{
	public function setadmin(Request $request)
	{
		return view('admin.setinterest');
	}
	
    public function setinterest()
    {
    	$setper = Setpercent::where('user_id', 1)->first();

        $lastid = DB::select('SELECT id FROM tests ORDER BY id DESC LIMIT 1');

        // dd($lastid);
        if (!empty($setper)) {
            if ($setper->min == $setper->max) 
                    DB::table('tests')->where('id', $lastid[0]->id)->update(['interest_rate' => $setper->max]); 
            else{
                    $randno = rand($setper->min, $setper->max);
                    DB::table('tests')->where('id', $lastid[0]->id)->update(['interest_rate' => $randno]); 
            }
        }
        return view('dashboard');
    }

    public function set_min_max_per(Request $request)
    {
    	 $min = $request->minpercent;
    	 $max = $request->maxpercent;
    	 $user_id = auth()->user()->id;

    	 if ($min < 0.01) 
    	 	return redirect()->back()->with('fail', 'You cannot enter min value less than 0.01.'); 
    	 elseif ($max > 100) 
    	 	return redirect()->back()->with('fail', 'You cannot enter max value more than 100.'); 
    	 elseif ($min > $max) 
    	 	return redirect()->back()->with('fail', 'You cannot enter min value greater than max.'); 


    	  
    	 $count = Setpercent::count();

    	 // dd($count);
    	  if ($count > 0) {
    	  		DB::table('setpercents')
    	              ->where('user_id', $user_id)
    	              ->update(['min' => $min,'max' => $max]);

    	  }else{
    	  	
    	 	 $per = new Setpercent;

    	 	 $per->min = $min;
    	 	 $per->max = $max;
    	 	 $per->user_id = $user_id;
    	 	 $per->save();
    	  }

    	  	 if ($min == $max) {
    	  	 		$interest_rate = DB::table('tests')->get();
    	  	 	  	// dd($interest_rate);
    	  	 	  	foreach ($interest_rate as $value) {
    						//set same interest rate for all pots
    	   	  				DB::table('tests')
    	   	  				            ->where('id', $value->id)
    	   	  				            ->update(['interest_rate' => $min]); 
    	  	 	  	}
    	  	 	  			//update same interest rate min and max for setpercents table
    	  	 	  			DB::table('setpercents')
    	  	 	  	            ->where('user_id', $user_id)
    	  	 	  	            ->update(['min' => $min,'max' => $min]);
    	  	 	return redirect()->back()->with('success', 'Updated Interest with Equal Interest of all POTS.'); 
    	  	 }

    	  	 return redirect()->back()->with('success', 'Interest rate updated successfully'); 
    }

    public function interestperpot()
    {
        // $users = User::get();
        $potInterests = DB::table('pots')
                    ->join('tests', 'pots.id', '=', 'tests.pot_id')
                    ->select('pots.*', 'tests.interest_rate')
                    ->paginate(10);
        return view('admin.interestperpot', compact('potInterests'));
    }

    public function setnewinterest(Request $request)
    {
        $pot_id = $request->potid;
        $newintreset = $request->newintreset;

        Test::where('pot_id', '=', $pot_id)->update(array('interest_rate' => $newintreset));
        
        return redirect()->back()->with('success', 'Interest update successfully'); 
    }
}
