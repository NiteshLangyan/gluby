<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Billing\PaymentGateway;
use App\Http\Requests\Donation\DonationStoreRequest;
use App\Transaction;

class DonationsController extends Controller
{    
    //
    private $paymentGateway;

    public function __construct(PaymentGateway $paymentGateway)
    {
        $this->paymentGateway = $paymentGateway;
        //$this->middleware('auth');
    }
    
    public function store(DonationStoreRequest $request)
    {
        $amount = number_format(request('amount'),10);
        // update amount to atomic value
        $amount = str_replace('.','',$amount);
        $user = auth()->user();

        // charge the user
        $this->paymentGateway->charge($amount, request('payment_token'));
        
        // create donation
        
        // if the user is not a member so its his first donation
        if(!$user->isActive()){
            
            event(new \App\Events\UserFirstDonation($user, $amount));
            //* Transaction transactions to wallet (event listener UserTransation)
            //* User Pot Wallet transfer money to his wallet (listener)
            //* User become active (listener)
            //* Transaction transaction to global pot (event listener SystemTransaction)
            //* Pot money to global pot (listener)
            //* UserPotSet become member of global pot (function)
            
            return redirect('/account')->withSuccess('Thank you to become a member');
        }
        
        event(new \App\Events\UserDonation($user, $amount));
            //* Transaction transactions to wallet (event listener UserTransation)
            //* User Pot Wallet transfer money to his wallet (listener)
        return redirect()->route('member.dashboard')->withSuccess('Thank you for your donation');
    }
    
    
    public function create()
    {
        return view('account.donate.create');
    }
}
