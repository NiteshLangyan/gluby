<?php

namespace App\Http\Middleware;

use Illuminate\Auth\AuthenticationException;
use Closure;

class Administrator
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if( auth()->check() ){
            if ( auth()->user()->isAdmin()){
                return $next($request);
            }
            return back()->withError('unauthorized');
        }
        return redirect('/login');
    }
}
