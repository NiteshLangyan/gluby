<?php

namespace App\Http\Requests\Pot;

use Illuminate\Foundation\Http\FormRequest;
use App\Rules\WalletAmount;
use App\Rules\AmountMustBeDecimal;
use Illuminate\Validation\Rule;
use App\Pot;

class PotUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'type' => ['required',
                Rule::in(['global', 'regular']),
            ],
            'name' => ['required', 'string',  Rule::unique('pots')->ignore( $this->pot['id'] ) ], 
        ];
    }
}
