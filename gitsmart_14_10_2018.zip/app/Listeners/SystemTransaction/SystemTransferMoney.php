<?php

namespace App\Listeners\SystemTransaction;

use App\Events\SystemTransaction;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class SystemTransferMoney
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  SystemTransaction  $event
     * @return void
     */
    public function handle(SystemTransaction $event)
    {
        $user = $event->user;
        $pot = $event->pot;
        $amount = $event->amount;
        $transaction = \App\Transaction::create([
            'user_id' => $user->id,
            'destination_type' => 'internal',
            'source_type' => 'internal',
            'amount' => $amount,
            'source_id' => $user->wallet()->id,
            'destination_id' => $pot->id,
        ]);
    }
}
