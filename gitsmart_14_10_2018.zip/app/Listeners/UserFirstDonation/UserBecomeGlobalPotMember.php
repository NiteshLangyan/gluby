<?php

namespace App\Listeners\UserFirstDonation;

use App\Events\UserFirstDonation;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class UserBecomeGlobalPotMember
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UserFirstDonation  $event
     * @return void
     */
    public function handle(UserFirstDonation $event)
    {
        $pot = \App\Pot::find(1)->first();
        $event->user->potMembership($pot);
    }
}
