<?php

namespace App\Listeners\UserFirstDonation;

use App\Events\UserFirstDonation;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class UpdateWalletCash
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {

    }

    /**
     * Handle the event.
     *
     * @param  UserFirstDonation  $event
     * @return void
     */
    public function handle(UserFirstDonation $event)
    {
        $potId = $event->user->wallet()->id;
        $pot = \App\Pot::find($potId);
        $amount = $event->amount;
        $user = $event->user;
        $firstAmount = $pot->amount;
        $pot->amount = $pot->amount + $amount;
        $pot->save();
        // update wallet cash
        event(new \App\Events\UserTransaction($user, $amount, $pot));
        $pot->amount = $firstAmount;
        return $pot->save();
        //
    }
}
