<?php

namespace App\Listeners\UserFirstDonation;

use App\Events\UserFirstDonation;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class DonateMoneyToGlobalPot
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UserFirstDonation  $event
     * @return void
     */
    public function handle(UserFirstDonation $event)
    {
        $pot = \App\Pot::find(1);
        $amount = $event->amount;
        $user = $event->user;
        // update GlobalPot
        event(new \App\Events\SystemTransaction($user, $amount, $pot));
        $pot->amount = $pot->amount + $amount;
        return $pot->save();
    }
}
