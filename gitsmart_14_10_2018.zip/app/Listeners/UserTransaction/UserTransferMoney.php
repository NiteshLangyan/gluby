<?php

namespace App\Listeners\UserTransaction;

use App\Events\UserTransaction;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class UserTransferMoney
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UserTransaction  $event
     * @return void
     */
    public function handle(UserTransaction $event)
    {
        $user = $event->user;
        $pot = $event->pot;
        $amount = $event->amount;
        $transaction = \App\Transaction::create([
            'user_id' => $user->id,
            'destination_type' => 'internal',
            'source_type' => 'external',
            'amount' => $amount,
            'source_id' => 99999,
            'destination_id' => $pot->id,
        ]);
        $transaction->save();
        return;
        //
    }
}
