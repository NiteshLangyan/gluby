<?php

namespace App\Listeners\UserPotDonation;

use App\Events\UserPotDonation;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class DonateFromWalletCash
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UserPotDonation  $event
     * @return void
     */
    public function handle(UserPotDonation $event)
    {
        $potId = $event->user->wallet()->id;
        $wallet = \App\Pot::find($potId);
        $pot = $event->pot;
        $amount = $event->amount;
        $user = $event->user;

        // update pot cash
        $pot->amount = $pot->amount + $amount;
        $pot->save();
        // update wallet cash
        $wallet->amount = $wallet->amount - $amount;
        $wallet->save();
        // pot membership
        $user->potMembership($pot);
        
        // transaction from wallet to pot
        return event(new \App\Events\SystemTransaction($user, $amount, $pot));
    }
}
