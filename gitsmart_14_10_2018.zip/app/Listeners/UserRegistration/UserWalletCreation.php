<?php

namespace App\Listeners\UserRegistration;

use App\Events\UserRegistration;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Pot;

class UserWalletCreation
{
    public $pot;
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct(Pot $pot)
    {
        return $this->pot = $pot;
    }

    /**
     * Handle the event.
     *
     * @param  UserRegistration  $event
     * @return void
     */
    public function handle(UserRegistration $event)
    {
        $pot = \App\Pot::where('name', $event->user->email)->get()->first();
        if(!$pot){
            $this->pot->user_id = $event->user->id;
            $this->pot->name = $event->user->email;
            $this->pot->type = 'wallet';
            return $this->pot->save();
        }
        return;
    }
}
