<?php

namespace App\Listeners\UserRelationToPot;

use App\Events\UserRelationToPot;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Setting;

class CreateSettingForThePotRelation
{
    public $setting;
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct(Setting $setting)
    {
        return $this->setting = $setting;
    }

    /**
     * Handle the event.
     *
     * @param  UserRelationToPot  $event
     * @return void
     */
    public function handle(UserRelationToPot $event)
    {
        $this->setting->name = rand[];
        $this->setting->save();
        $event->userpotset->setting_id = $this->setting->id;
    }
}
