<?php

namespace App\Listeners\UserDonation;

use App\Events\UserDonation;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class UserWalletCash
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UserDonation  $event
     * @return void
     */
    public function handle(UserDonation $event)
    {
        $potId = $event->user->wallet()->id;
        $pot = \App\Pot::find($potId);
        $amount = $event->amount;
        $user = $event->user;
        
        // update wallet cash
        $pot->amount = $pot->amount + $amount;
        $pot->save();
        
        // transaction
        event(new \App\Events\UserTransaction($user, $amount, $pot));
    }
}
