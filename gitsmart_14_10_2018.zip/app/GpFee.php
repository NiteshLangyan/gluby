<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GpFee extends Model
{

	protected $fillable = [
	    'gp_fee', 'pot_id',
	];
    public function pot()
    {
    	return $this->belongsTo('App\Pot', 'pot_id');
    }
}
