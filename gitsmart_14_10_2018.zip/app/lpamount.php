<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class lpamount extends Model
{
    //
}
