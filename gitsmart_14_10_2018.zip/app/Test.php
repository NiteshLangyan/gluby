<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Test extends Model
{
    //
    protected $fillable = [
        'pot_id',
    ];
    
    protected $guarted = [];

    public function pot()
    {
        return $this->belongsTo('App\Pot', 'pot_id');
    }
    
    

}
