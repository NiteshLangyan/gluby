<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\User;
use App\Setting;

class Pot extends Model
{
    //
    protected $guarded = [];

    public function owner()
    {
        return $this->belongsTo('App\User', 'user_id');
    }

    public function potTransactions()
    {
        return \App\Transaction::where('source_id', $this->id )
                                    ->where('source_type' , 'internal')
                                        ->orWhere(function($query){
                                            $query->where('destination_id' , $this->id )
                                            ->where('destination_type' , 'internal');
                                        })
                                    ->get();
    }
    
     
    

    /*
    public function owners()
    {
        return $this->belongsToMany(User::class, 'user_pot_set', 'pot_id', 'user_id')->withPivot('setting_id')->withTimestamps();
    }
    
    
    public function settings()
    {
        return $this->belongsToMany(Setting::class, 'user_pot_set', 'pot_id', 'setting_id')->withPivot('user_id')->withTimestamps();
    }
*/


    public function potSettingUser($potId, $userId)
    {
        $yes = \App\UserPotSet::where('pot_id' , $potId )->where( 'user_id' , $userId)->get();
    
                                                                //->pluck('user_id');

        return \App\Setting::where($yes)->get();
    }
/*
    // pot->members
    // many to many
    public function potations()
    {
        return $this->morphedByMany(User::class, 'potable')->withPivot('amount')->withTimestamps();
    }

    // pot->owner
    // one to one PotCreator
    public function owner()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
    
 */
    /*
   public function creator()
   {
        return $this->morphedByMany(User::class, 'user_id');
   }
   **/
    
    
   public function potate($amount)
   {
       $this->potations()->create([ 'user_id' => auth()->id(), 'amount' => $amount ]);
   }
   
   public function test()
   {
       return $this->hasOne(Test::class);
   }
     
   public function gpfee()
   {
       return $this->hasOne(GpFee::class);
   }
     
    
    
    
}
