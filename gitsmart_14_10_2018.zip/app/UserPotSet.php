<?php

namespace App;

//use Illuminate\Database\Eloquent\Relations\Pivot;

use Illuminate\Database\Eloquent\Model;

class UserPotSet extends Model
{
    //
    public $table = 'user_pot_set';


    public static function potSetting($potId, $userId)
    {
         return UserPotSet::where('user_id', $userId)->where('pot_id', $potId)->get()->pluck('setting_id');
    }
}
