<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Pot;

class Setting extends Model
{
    //
    
    protected $guarded = [];
/*
    public function pots()
    {
        return $this->belongsToMany(Pot::class, 'user_pot_set', 'setting_id', 'pot_id')->withPivot('user_id')->withTimestamps();
    }
 */
    
    
    
    
}
