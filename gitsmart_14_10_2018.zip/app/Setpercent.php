<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Setpercent extends Model
{
    protected $fillable = [
        'max', 'min',
    ];
}
