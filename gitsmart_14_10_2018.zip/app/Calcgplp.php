<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Calcgplp extends Model
{
    //
}
