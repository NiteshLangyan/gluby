<?php

namespace App\Providers;

use Illuminate\Support\Facades\Event;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event listener mappings for the application.
     *
     * @var array
     */
    protected $listen = [
        'App\Events\UserRegistration' => [
            'App\Listeners\UserRegistration\UserWalletCreation',
        ],
        'App\Events\UserFirstDonation' => [
            'App\Listeners\UserFirstDonation\UpdateWalletCash', // Update Wallet
            'App\Listeners\UserFirstDonation\DonateMoneyToGlobalPot',
            'App\Listeners\UserFirstDonation\UserBecomeGlobalPotMember',
            'App\Listeners\UserFirstDonation\UserBecomeActive',
        ],
        //'App\Events\UserRelationToPot' => [
        //  'App\Listeners\UserRelationToPot\CreateSettingForThePotRelation',
        //],
        'App\Events\UserTransaction' => [ //transact money to wallet
            'App\Listeners\UserTransaction\UserTransferMoney',
        ],
        'App\Events\SystemTransaction' => [
            'App\Listeners\SystemTransaction\SystemTransferMoney',
        ],
        'App\Events\UserDonation' => [
            'App\Listeners\UserDonation\UserWalletCash',
        ],
        'App\Events\UserPotDonation' => [
            'App\Listeners\UserPotDonation\DonateFromWalletCash',
        ],

    ];

    /**
     * Register any events for your application.
     *
     * @return void
     */
    public function boot()
    {
        parent::boot();

        //
    }
}
