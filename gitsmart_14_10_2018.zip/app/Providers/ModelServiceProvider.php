<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class ModelServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
       \App\User::observe(\App\Observers\UserObserver::class); 
       \App\Pot::observe(\App\Observers\PotObserver::class); 
       \App\UserPotSet::observe(\App\Observers\UserPotSetObserver::class); 
       \App\Setting::observe(\App\Observers\SettingObserver::class); 
       \App\Transaction::observe(\App\Observers\TransactionObserver::class); 
        //
    }

    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
