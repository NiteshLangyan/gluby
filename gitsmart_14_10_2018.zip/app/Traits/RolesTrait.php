<?php

namespace App\Traits;

Trait RolesTrait
{
    // check if user is a member
    public function isActive()
    {
        if ($this->role == 'active'  ){
            return true;
        }
        return false;
    }

    public function becomeActive()
    {
        $this->role = 'active';
        return $this->save();
    }

    // check if user is a member
    public function isAdmin()
    {
        if ( $this->is_admin == true){
            return true;
        }
        return false;
    }

    // admin status
    public function AdminStatus()
    {
        if($this->is_admin == true ){
            return 'Admin';
        }
        return 'Not Admin';
    }

    // convert the user tobecome an admin
    public function beAdmin()
    {
        $this->is_admin = true;
        return $this->save();
    }

    // convert the user tobecome a regular user
    public function beNotAdmin()
    {
        $this->is_admin = false;
        return $this->save();
    }

}
