<?php

namespace App\Traits;

Trait MoneyOperationsTrait
{
    // userId user()->id() coming from the request
    // amount coming from the request
    
    //donate the user function to add to his donations table
    public function donate($userId, $amount)
    {
        $this->donations()->create([ 'user_id' => $userId, 'amount' => $amount]);
        return;
    }
    
    // donate a user using his id and the amount
    public function PutInWallet($userId, $amount)
    {
        $this->donate($userId, $amount);
        $this->InWallet($amount);
        return $this;
    }

    // put money in the user wallet or substract money from his wallet $amount come from the request
    public function InWallet($amount)
    {
        $userWallet = $this->wallet;
        $this->wallet = $userWallet + $amount;
        return $this->save();
    }

    // first donation of a user 
    public function PotDonation($userId, $amount, $potId )
    {
        $potId = 1;
        $this->donate($userId, $amount);
        $pot = \App\Pot::find($potId);
        $pot->id = 1;
        $this->pots()->save( $pot, ['setting_id' => 1] );
            //update pot amount
            $potAmount = $pot->amount;
            $potAmount = $potAmount + $amount ;
            $pot->update( ['amount' => $potAmount]);
            $pot->save();
            return $this;
    }

}
